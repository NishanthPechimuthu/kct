<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a passenger
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'passenger') {
    header('Location: /login.html');
    exit;
}

$ride_id = $_GET['ride_id'] ?? null;
if (!$ride_id) {
    // Redirect to dashboard if no ride ID is provided
    header('Location: /passenger/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ride Info - eTaxi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <style>
        #map { height: 400px; z-index: 10; }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100">

    <?php include 'navbar.php'; ?>

    <main class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Your Ride Status</h1>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="md:col-span-2 bg-white p-6 rounded-lg shadow-lg">
                <div id="map" class="rounded-lg"></div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-2xl font-bold mb-4">Ride Details</h2>
                <div id="ride-info-container" class="space-y-4">
                    <div class="animate-pulse">
                        <div class="h-4 bg-gray-200 rounded w-1/4"></div>
                        <div class="h-6 bg-gray-300 rounded w-1/2 mt-1"></div>
                    </div>
                    <div class="animate-pulse">
                        <div class="h-4 bg-gray-200 rounded w-1/4"></div>
                        <div class="h-6 bg-gray-300 rounded w-1/2 mt-1"></div>
                    </div>
                    <div class="animate-pulse">
                        <div class="h-4 bg-gray-200 rounded w-1/4"></div>
                        <div class="h-6 bg-gray-300 rounded w-1/2 mt-1"></div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const rideId = <?= json_encode($ride_id) ?>;
            const map = L.map('map').setView([11.0168, 76.9558], 13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

            const rideInfoContainer = document.getElementById('ride-info-container');
            let driverMarker;

            const fetchRideInfo = async () => {
                try {
                    const response = await axios.get(`/api/rides.php?action=get_ride_info&ride_id=${rideId}`);
                    if (response.data.success) {
                        const ride = response.data.data;
                        updateRideInfo(ride);
                        updateMap(ride);
                    } else {
                        rideInfoContainer.innerHTML = `<p class="text-red-500">${response.data.message}</p>`;
                    }
                } catch (error) {
                    const message = error.response ? error.response.data.message : error.message;
                    rideInfoContainer.innerHTML = `<p class="text-red-500">Could not load ride details: ${message}</p>`;
                }
            };

            const updateRideInfo = (ride) => {
                console.log(ride);
                if (ride.ride_status === 'completed') {
                    rideInfoContainer.innerHTML = '<p class="text-green-500 font-bold">Ride completed! Redirecting to dashboard...</p>';
                    setTimeout(() => {
                        window.location.href = '/passenger/dashboard.php';
                    }, 2000);
                    return;
                }

                let driverInfoHTML = '';
                if (ride.ride_status === 'accepted' || ride.ride_status === 'in_progress') {
                    driverInfoHTML = `
                        <div class="flex items-center">
                            <i class="fas fa-user-circle text-2xl text-gray-400 mr-4"></i>
                            <div>
                                <p class="text-gray-600">Driver</p>
                                <p class="text-xl font-bold">${ride.driver_name}</p>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-car text-2xl text-gray-400 mr-4"></i>
                            <div>
                                <p class="text-gray-600">Vehicle</p>
                                <p class="text-xl font-bold">${ride.year} ${ride.make} ${ride.model} (${ride.color})</p>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-car text-2xl text-gray-400 mr-4"></i>
                            <div>
                                <p class="text-gray-600">License Plate</p>
                                <p class="text-xl font-bold">${ride.license_plate}</p>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-phone text-2xl text-gray-400 mr-4"></i>
                            <div>
                                <p class="text-gray-600">Driver Phone</p>
                                <p class="text-xl font-bold">${ride.driver_phone || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="mt-4 p-4 bg-blue-50 rounded-lg text-center">
                            <p class="text-gray-600">Your OTP</p>
                            <p class="text-3xl font-extrabold text-blue-500 tracking-widest">${ride.otp}</p>
                        </div>
                    `;
                } else {
                    driverInfoHTML = `
                        <div class="flex items-center">
                            <i class="fas fa-spinner fa-spin text-2xl text-gray-400 mr-4"></i>
                            <div>
                                <p class="text-gray-600">Driver</p>
                                <p class="text-xl font-bold">Searching for a driver...</p>
                            </div>
                        </div>
                    `;
                }

                let paymentButton = '';
                if (ride.ride_status === 'in_progress' && ride.payment_status === 'pending') {
                    paymentButton = `<a href="/passenger/payment.php?payment_id=${ride.payment_id}&amount=${ride.fare}&description=Ride Payment" class="mt-6 w-full text-center bg-green-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-600 transition-colors duration-300">Pay Now</a>`;
                }

                let cancelButton = '';
                if (ride.ride_status === 'accepted') {
                    cancelButton = `<button id="cancel-ride-btn" data-ride-id="${ride.ride_id}" class="mt-4 w-full bg-red-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-600">Cancel Ride</button>`;
                }

                rideInfoContainer.innerHTML = `
                    <div class="space-y-6">
                        <div class="flex items-center">
                            <i class="fas fa-info-circle text-2xl text-gray-400 mr-4"></i>
                            <div>
                                <p class="text-gray-600">Status</p>
                                <p class="text-xl font-bold">${ride.ride_status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
                            </div>
                        </div>
                        ${driverInfoHTML}
                        <div class="mt-6">
                            ${paymentButton}
                            ${cancelButton}
                        </div>
                    </div>
                `;
            };

            const updateMap = (ride) => {
                if (ride.driver_lat && ride.driver_lng) {
                    const driverLatLng = [ride.driver_lat, ride.driver_lng];
                    if (driverMarker) {
                        driverMarker.setLatLng(driverLatLng);
                    } else {
                        driverMarker = L.marker(driverLatLng).addTo(map).bindPopup('Your Driver');
                    }
                    map.setView(driverLatLng, 15);
                }
            };

            rideInfoContainer.addEventListener('click', async (event) => {
                if (event.target.id === 'cancel-ride-btn') {
                    const rideId = event.target.dataset.rideId;
                    try {
                        const response = await axios.post('/api/rides.php', { 
                            action: 'cancel_by_passenger', 
                            ride_id: rideId 
                        });
                        if (response.data.success) {
                            Swal.fire('Cancelled!', 'Ride Cancelled Successfully', 'success').then(() => {
                                window.location.href = '/passenger/dashboard.php';
                            });
                        } else {
                            throw new Error(response.data.message);
                        }
                    } catch (error) {
                        Swal.fire('Failed to cancel ride: ' + error.message);
                    }
                }
            });

            fetchRideInfo();
            setInterval(fetchRideInfo, 5000); // Poll every 5 seconds
        });
    </script>
</body>
</html>