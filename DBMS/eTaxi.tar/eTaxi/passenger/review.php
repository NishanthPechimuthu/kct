<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'passenger') {
    header('Location: /login.html');
    exit;
}

require '../config/db.php';

$ride_id = $_GET['ride_id'] ?? null;

if (!$ride_id) {
    header('Location: /passenger/dashboard.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM rides WHERE ride_id = ? AND passenger_id = ? AND ride_status = 'completed'");
$stmt->execute([$ride_id, $_SESSION['user_id']]);
$ride = $stmt->fetch();

if (!$ride) {
    header('Location: /passenger/dashboard.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Your Ride - eTaxi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Review Your Ride</h1>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <form id="review-form">
                <input type="hidden" name="action" value="submit_review">
                <input type="hidden" name="ride_id" value="<?= $ride_id ?>">
                <input type="hidden" name="driver_id" value="<?= $ride['driver_id'] ?>">
                <div class="mb-4">
                    <label for="rating" class="block text-sm font-medium text-gray-700">Rating</label>
                    <select id="rating" name="rating" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                        <option value="5">5 - Excellent</option>
                        <option value="4">4 - Good</option>
                        <option value="3">3 - Average</option>
                        <option value="2">2 - Poor</option>
                        <option value="1">1 - Terrible</option>
                    </select>
                </div>
                <div class="mb-4">
                    <label for="comment" class="block text-sm font-medium text-gray-700">Comment (Optional)</label>
                    <textarea id="comment" name="comment" rows="4" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm"></textarea>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-600">Submit Review</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>
        document.getElementById('review-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            try {
                const response = await axios.post('/api/passenger.php', formData);
                if (response.data.success) {
                    Swal.fire('Success!', response.data.message, 'success').then(() => {
                        window.location.href = '/passenger/dashboard.php';
                    });
                } else {
                    throw new Error(response.data.message);
                }
            } catch (error) {
                Swal.fire('Error!', error.message, 'error');
            }
        });
    </script>
</body>
</html>