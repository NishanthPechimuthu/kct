<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a passenger
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'passenger') {
    header('Location: /login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Phone Number - eTaxi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Update Your Phone Number</h1>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <p class="text-gray-600 mb-4">To book a ride, you need to have a phone number associated with your account.</p>
            <form id="update-phone-form">
                <input type="hidden" name="action" value="update_phone">
                <div class="mb-4">
                    <label for="phone_number" class="block text-sm font-medium text-gray-700">Phone Number</label>
                    <input type="text" id="phone_number" name="phone_number" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-600">Update Phone Number</button>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('update-phone-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const phoneNumber = formData.get('phone_number');

            if (!phoneNumber) {
                Swal.fire('Error', 'Phone number cannot be empty.', 'error');
                return;
            }

            try {
                const response = await axios.post('/api/passenger.php', formData);
                if (response.data.success) {
                    Swal.fire('Success', 'Phone number updated successfully!', 'success').then(() => {
                        window.location.href = '/passenger/dashboard.php';
                    });
                } else {
                    throw new Error(response.data.message);
                }
            } catch (error) {
                Swal.fire('Error', error.message || 'Could not update phone number.', 'error');
            }
        });
    </script>
</body>
</html>