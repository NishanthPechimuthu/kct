#!/usr/bin/env python3
import mysql.connector
from faker import Faker
import random
from datetime import datetime, timedelta, date

# ----------------------------------------------------------------------
# 1. DB connection & Faker
# ----------------------------------------------------------------------
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="taxi"
)
cursor = db.cursor()
fake = Faker()

# ----------------------------------------------------------------------
# 2. Constants – 3-month window
# ----------------------------------------------------------------------
NOW = datetime.now()
THREE_MONTHS_AGO = NOW - timedelta(days=90)

NUM_USERS       = 200
NUM_DRIVERS     = 50
NUM_PASSENGERS  = 140
NUM_ADMINS      = 10
NUM_RIDES       = 150

# ----------------------------------------------------------------------
# 3. Helper – random datetime inside the 3-month window
# ----------------------------------------------------------------------
def rand_date_in_window():
    """Return a random datetime between THREE_MONTHS_AGO and NOW."""
    delta = NOW - THREE_MONTHS_AGO
    random_seconds = random.randint(0, int(delta.total_seconds()))
    return THREE_MONTHS_AGO + timedelta(seconds=random_seconds)

# ----------------------------------------------------------------------
# 4. Truncate everything (unchanged)
# ----------------------------------------------------------------------
def truncate_tables():
    tables = [
        'suspensions', 'passenger_reviews', 'driver_reviews', 'Payments',
        'Rides', 'Subscriptions', 'driver_vehicles', 'Driver_Maintenance',
        'Admins', 'Drivers', 'Passengers', 'subscription_plans',
        'Users', 'Vehicles'
    ]
    try:
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        for t in tables:
            try:
                cursor.execute(f"TRUNCATE TABLE {t}")
                db.commit()
                print(f"Table {t} truncated.")
            except mysql.connector.Error as err:
                if err.errno != 1146:   # table does not exist
                    raise
    finally:
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")

# ----------------------------------------------------------------------
# 5. Users – registration spread over 3 months
# ----------------------------------------------------------------------
def appraisal_users():
    users = []
    for _ in range(NUM_USERS):
        full_name = fake.name()
        email     = fake.email()
        role      = random.choices(
            ['driver', 'passenger', 'admin'],
            weights=[NUM_DRIVERS, NUM_PASSENGERS, NUM_ADMINS],
            k=1
        )[0]
        phone_number   = fake.numerify('##########')
        password_hash  = fake.password()
        registration_date = rand_date_in_window()
        users.append((full_name, email, password_hash, phone_number, role, registration_date))

    sql = """INSERT INTO Users
             (full_name, email, password_hash, phone_number, role, registration_date)
             VALUES (%s,%s,%s,%s,%s,%s)"""
    cursor.executemany(sql, users)
    db.commit()
    print(f"{cursor.rowcount} users inserted.")

# ----------------------------------------------------------------------
# 6. Helper – fetch ids by role
# ----------------------------------------------------------------------
def get_user_ids(role):
    cursor.execute("SELECT user_id FROM Users WHERE role = %s", (role,))
    return [row[0] for row in cursor.fetchall()]

# ----------------------------------------------------------------------
# 7. Drivers + Vehicles + Maintenance (unchanged logic, dates spread)
# ----------------------------------------------------------------------
def appraisal_drivers():
    driver_ids = get_user_ids('driver')
    drivers, vehicles, driver_vehicles, maintenance = [], [], [], []

    for driver_id in driver_ids:
        # ---- driver record -------------------------------------------------
        license_number = fake.bothify('TN##-####-#######')
        rc_number      = fake.bothify('TN##-R-####')
        drivers.append((driver_id, license_number, rc_number))

        # ---- vehicle -------------------------------------------------------
        make   = random.choice(['Toyota','Honda','Ford','Maruti Suzuki','Hyundai'])
        model  = fake.word()
        year   = random.randint(2015, 2023)
        color  = fake.color_name()
        plate  = fake.bothify('TN-##-??-####')
        vehicles.append((make, model, year, color, plate))

    # insert drivers
    cursor.executemany(
        "INSERT INTO Drivers (driver_id, license_number, rc_number) VALUES (%s,%s,%s)",
        drivers
    )
    db.commit()
    print(f"{cursor.rowcount} drivers inserted.")

    # insert vehicles
    cursor.executemany(
        "INSERT INTO Vehicles (make,model,year,color,license_plate) VALUES (%s,%s,%s,%s,%s)",
        vehicles
    )
    db.commit()
    print(f"{cursor.rowcount} vehicles inserted.")

    # link driver ↔ vehicle (1-to-1)
    cursor.execute(f"SELECT vehicle_id FROM Vehicles ORDER BY vehicle_id DESC LIMIT {len(driver_ids)}")
    vehicle_ids = [row[0] for row in cursor.fetchall()][::-1]
    driver_vehicles = list(zip(driver_ids, vehicle_ids))

    cursor.executemany(
        "INSERT INTO driver_vehicles (driver_id, vehicle_id) VALUES (%s,%s)",
        driver_vehicles
    )
    db.commit()
    print(f"{cursor.rowcount} driver-vehicle links inserted.")

    # ---- maintenance documents (spread over 3 months) --------------------
    doc_types = [
        'RC (Registration Certificate)', 'Pollution Under Control (PUC) Certificate',
        'Insurance Certificate', 'Fitness Certificate', 'Permit for Commercial Vehicle',
        "Driver's License"
    ]
    for driver_id in driver_ids:
        for doc in doc_types:
            upload_date = rand_date_in_window()
            expiry_date = upload_date + timedelta(days=random.randint(30, 365))
            maintenance.append((
                driver_id, doc,
                fake.bothify('??########'),
                f"data/maintenance_documents/doc_{fake.uuid4()}.pdf",
                upload_date, upload_date + timedelta(days=random.randint(30, 365)),  # next_due_date
                expiry_date,
                random.choice(['approved','pending','rejected'])
            ))

    cursor.executemany(
        """INSERT INTO Driver_Maintenance
           (driver_id,document_type,document_number,document_path,
            upload_date,next_due_date,expiry_date,approval_status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
        maintenance
    )
    db.commit()
    print(f"{cursor.rowcount} maintenance docs inserted.")

# ----------------------------------------------------------------------
# 8. Admins & Passengers (simple 1-to-1 tables)
# ----------------------------------------------------------------------
def appraisal_admins():
    admin_ids = get_user_ids('admin')
    cursor.executemany("INSERT INTO Admins (admin_id) VALUES (%s)", [(i,) for i in admin_ids])
    db.commit()
    print(f"{cursor.rowcount} admins inserted.")

def appraisal_passengers():
    passenger_ids = get_user_ids('passenger')
    cursor.executemany("INSERT INTO Passengers (passenger_id) VALUES (%s)", [(i,) for i in passenger_ids])
    db.commit()
    print(f"{cursor.rowcount} passengers inserted.")

# ----------------------------------------------------------------------
# 9. Subscription plans (static)
# ----------------------------------------------------------------------
def appraisal_subscription_plans():
    plans = [
        ('Basic',     1000, None, 10, 15, 10, 25, 'Monthly plan with 10 rides'),
        ('Premium',   2500, 2200, 25, 20, 10, 25, 'Monthly plan with 25 rides and discount'),
        ('Gold',      4000, 3500, 50, 25, 10, 25, 'Monthly plan with 50 rides and discount'),
        ('Corporate', 6000, None, 100,30, 10, 25, 'Monthly plan for corporate users'),
        ('Student',    800, None, 15, 15, 10, 25, 'Discounted plan for students')
    ]
    cursor.executemany(
        """INSERT INTO subscription_plans
           (plan_name,price,discounted_price,max_rides,max_km_per_ride,
            extra_km_charge_percent,extra_ride_charge_percent,description)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
        plans
    )
    db.commit()
    print(f"{cursor.rowcount} subscription plans inserted.")

# ----------------------------------------------------------------------
# 10. Subscriptions – 20 random passengers, dates inside 3-month window
# ----------------------------------------------------------------------
def appraisal_subscriptions():
    passenger_ids = get_user_ids('passenger')
    plan_ids = [1,2,3,4,5]
    subs = []
    for _ in range(20):
        start = rand_date_in_window()
        end   = start + timedelta(days=30)
        subs.append((
            random.choice(passenger_ids),
            random.choice(plan_ids),
            start.date(), end.date(),
            end.date() >= date.today()
        ))
    cursor.executemany(
        "INSERT INTO Subscriptions (passenger_id,plan_id,start_date,end_date,is_active) VALUES (%s,%s,%s,%s,%s)",
        subs
    )
    db.commit()
    print(f"{cursor.rowcount} subscriptions inserted.")

# ----------------------------------------------------------------------
# 11. Rides – spread over 3 months + a few “special” dates
# ----------------------------------------------------------------------
def appraisal_rides():
    passenger_ids = get_user_ids('passenger')
    driver_ids    = get_user_ids('driver')
    rides = []

    # ---- 1. Bulk rides (evenly spread) ---------------------------------
    for _ in range(NUM_RIDES - 12):          # leave 12 slots for special dates
        passenger_id = random.choice(passenger_ids)
        driver_id    = random.choice(driver_ids)

        # pick city
        if random.random() < 0.5:
            lat_range, lng_range = (11.004556, 11.024556), (76.954536, 76.974536)
            city = "Coimbatore"
        else:
            lat_range, lng_range = (10.6573, 10.6773), (77.0023, 77.0223)
            city = "Pollachi"

        pickup_lat  = random.uniform(*lat_range)
        pickup_lng  = random.uniform(*lng_range)
        dropoff_lat = random.uniform(*lat_range)
        dropoff_lng = random.uniform(*lng_range)
        pickup_addr  = f"{fake.street_address()}, {city}"
        dropoff_addr = f"{fake.street_address()}, {city}"

        distance_km = random.uniform(1, 20)
        fare        = 50 + distance_km * 15
        driver_fare = fare * 0.8
        status      = random.choice([
            'requested','accepted','in_progress','completed',
            'cancelled_by_driver','cancelled_by_passenger'
        ])

        request_time = rand_date_in_window()
        start_time   = (request_time + timedelta(minutes=random.randint(1,10))
                        if status != 'requested' else None)
        end_time     = (start_time + timedelta(minutes=random.randint(5,60))
                        if status == 'completed' else None)

        rides.append((
            passenger_id, driver_id,
            pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
            pickup_addr, dropoff_addr,
            distance_km, fare, driver_fare,
            str(random.randint(1000,9999)),
            status, request_time, start_time, end_time
        ))

    # ---- 2. 12 “special-date” rides (hand-picked dates) ----------------
    special_dates = [
        THREE_MONTHS_AGO + timedelta(days=7),   # 1 week after start
        THREE_MONTHS_AGO + timedelta(days=14),
        THREE_MONTHS_AGO + timedelta(days=21),
        THREE_MONTHS_AGO + timedelta(days=30),
        THREE_MONTHS_AGO + timedelta(days=45),
        THREE_MONTHS_AGO + timedelta(days=60),
        THREE_MONTHS_AGO + timedelta(days=75),
        datetime.now() - timedelta(days=5),    # 5 days ago
        datetime.now() - timedelta(days=3),
        datetime.now() - timedelta(days=1),
        datetime.now() - timedelta(hours=12),
        datetime.now() - timedelta(hours=2)
    ]

    for base_dt in special_dates:
        passenger_id = random.choice(passenger_ids)
        driver_id    = random.choice(driver_ids)

        # reuse city logic (Coimbatore for simplicity)
        pickup_lat  = random.uniform(11.004556, 11.024556)
        pickup_lng  = random.uniform(76.954536, 76.974536)
        dropoff_lat = random.uniform(11.004556, 11.024556)
        dropoff_lng = random.uniform(76.954536, 76.974536)
        pickup_addr  = f"{fake.street_address()}, Coimbatore"
        dropoff_addr = f"{fake.street_address()}, Coimbatore"

        distance_km = random.uniform(3, 12)
        fare        = 50 + distance_km * 15
        driver_fare = fare * 0.8
        status      = random.choice(['completed','cancelled_by_passenger'])

        request_time = base_dt
        start_time   = request_time + timedelta(minutes=random.randint(2,8))
        end_time     = (start_time + timedelta(minutes=random.randint(10,40))
                        if status == 'completed' else None)

        rides.append((
            passenger_id, driver_id,
            pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
            pickup_addr, dropoff_addr,
            distance_km, fare, driver_fare,
            str(random.randint(1000,9999)),
            status, request_time, start_time, end_time
        ))

    # ---- Insert -------------------------------------------------------
    cursor.executemany(
        """INSERT INTO Rides
           (passenger_id,driver_id,
            pickup_location_lat,pickup_location_lng,
            dropoff_location_lat,dropoff_location_lng,
            pickup_address,dropoff_address,
            distance_km,fare,driver_fare,otp,
            ride_status,request_time,start_time,end_time)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        rides
    )
    db.commit()
    print(f"{cursor.rowcount} rides inserted (incl. 12 special-date rides).")

# ----------------------------------------------------------------------
# 12. Payments – only for completed rides
# ----------------------------------------------------------------------
def appraisal_payments():
    cursor.execute(
        "SELECT ride_id, passenger_id, driver_fare FROM Rides WHERE ride_status='completed'"
    )
    completed = cursor.fetchall()
    payments = []
    for ride_id, passenger_id, amount in completed:
        payments.append((
            passenger_id, ride_id, amount,
            random.choice(['card','cash','wallet']),
            'completed',
            fake.uuid4()
        ))
    cursor.executemany(
        "INSERT INTO Payments (user_id,ride_id,amount,payment_method,payment_status,transaction_id) VALUES (%s,%s,%s,%s,%s,%s)",
        payments
    )
    db.commit()
    print(f"{cursor.rowcount} payments inserted.")

# ----------------------------------------------------------------------
# 13. Reviews – passenger (optional) + driver (mandatory)
# ----------------------------------------------------------------------
def appraisal_reviews():
    cursor.execute(
        "SELECT ride_id, driver_id, passenger_id FROM Rides WHERE ride_status='completed'"
    )
    completed = cursor.fetchall()

    passenger_rev = []
    driver_rev    = []

    for ride_id, driver_id, passenger_id in completed:
        # ---- passenger review (50 % chance) ---------------------------
        if random.random() < 0.5:
            passenger_rev.append((
                ride_id, driver_id, passenger_id,
                random.randint(1,5), fake.sentence()
            ))

        # ---- driver review (always) ----------------------------------
        driver_rev.append((
            ride_id, passenger_id, driver_id,
            random.randint(1,5), fake.sentence()
        ))

    cursor.executemany(
        "INSERT INTO passenger_reviews (ride_id,driver_id,passenger_id,rating,comment) VALUES (%s,%s,%s,%s,%s)",
        passenger_rev
    )
    db.commit()
    print(f"{cursor.rowcount} passenger reviews inserted.")

    cursor.executemany(
        "INSERT INTO driver_reviews (ride_id,passenger_id,driver_id,rating,comment) VALUES (%s,%s,%s,%s,%s)",
        driver_rev
    )
    db.commit()
    print(f"{cursor.rowcount} driver reviews inserted.")

# ----------------------------------------------------------------------
# 14. Suspended users (5 random users)
# ----------------------------------------------------------------------
def appraisal_suspended_users():
    all_user_ids = get_user_ids('driver') + get_user_ids('passenger')
    suspended = []
    for _ in range(5):
        uid = random.choice(all_user_ids)
        end = rand_date_in_window() + timedelta(days=random.randint(1,30))
        suspended.append((uid, end, fake.sentence()))
    try:
        cursor.executemany(
            "INSERT INTO suspensions (user_id,end_date,reason) VALUES (%s,%s,%s)",
            suspended
        )
        db.commit()
        print(f"{cursor.rowcount} suspended users inserted.")
    except mysql.connector.Error as err:
        if err.errno == 1146:
            print("Warning: `suspensions` table missing – skipped.")
        else:
            raise

# ----------------------------------------------------------------------
# 15. MAIN – run everything in the correct order
# ----------------------------------------------------------------------
if __name__ == "__main__":
    truncate_tables()
    appraisal_users()
    appraisal_drivers()
    appraisal_admins()
    appraisal_passengers()
    appraisal_subscription_plans()
    appraisal_subscriptions()
    appraisal_rides()
    appraisal_payments()
    appraisal_reviews()
    appraisal_suspended_users()

    cursor.close()
    db.close()