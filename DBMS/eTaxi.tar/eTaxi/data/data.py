
import mysql.connector
from faker import Faker
import random
from datetime import datetime, timedelta

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="taxi"
)
cursor = db.cursor()
fake = Faker()

# Constants
NUM_USERS = 200
NUM_DRIVERS = 50
NUM_PASSENGERS = 140
NUM_ADMINS = 10
NUM_RIDES = 150

# Coimbatore and Pollachi coordinates
COIMBATORE_LAT_RANGE = (11.004556, 11.024556)
COIMBATORE_LNG_RANGE = (76.954536, 76.974536)
POLLACHI_LAT_RANGE = (10.6573, 10.6773)
POLLACHI_LNG_RANGE = (77.0023, 77.0223)

def generate_users():
    users = []
    for i in range(NUM_USERS):
        full_name = fake.name()
        email = fake.email()
        role = random.choices(['driver', 'passenger', 'admin'], weights=[NUM_DRIVERS, NUM_PASSENGERS, NUM_ADMINS], k=1)[0]
        phone_number = fake.numerify(text='##########')
        password_hash = fake.password()
        registration_date = fake.date_time_between(start_date="-3M", end_date="now")
        users.append((full_name, email, password_hash, phone_number, role, registration_date))
    
    query = "INSERT INTO Users (full_name, email, password_hash, phone_number, role, registration_date) VALUES (%s, %s, %s, %s, %s, %s)"
    cursor.executemany(query, users)
    db.commit()
    print(f"{cursor.rowcount} users inserted.")

def get_user_ids(role):
    query = "SELECT user_id FROM Users WHERE role = %s"
    cursor.execute(query, (role,))
    return [item[0] for item in cursor.fetchall()]

def generate_drivers():
    driver_ids = get_user_ids('driver')
    drivers = []
    vehicles = []
    driver_vehicles = []
    maintenance_docs = []

    for driver_id in driver_ids:
        license_number = fake.bothify(text='TN##-####-#######')
        rc_number = fake.bothify(text='TN##-R-####')
        drivers.append((driver_id, license_number, rc_number))

        make = random.choice(['Toyota', 'Honda', 'Ford', 'Maruti Suzuki', 'Hyundai'])
        model = fake.word()
        year = random.randint(2015, 2023)
        color = fake.color_name()
        license_plate = fake.bothify(text='TN-##-??-####')
        vehicles.append((make, model, year, color, license_plate))

    # Insert drivers
    query = "INSERT INTO Drivers (driver_id, license_number, rc_number) VALUES (%s, %s, %s)"
    cursor.executemany(query, drivers)
    db.commit()
    print(f"{cursor.rowcount} drivers inserted.")

    # Insert vehicles
    query = "INSERT INTO Vehicles (make, model, year, color, license_plate) VALUES (%s, %s, %s, %s, %s)"
    cursor.executemany(query, vehicles)
    db.commit()
    print(f"{cursor.rowcount} vehicles inserted.")

    # Get vehicle and driver ids for mapping
    cursor.execute("SELECT vehicle_id FROM Vehicles ORDER BY vehicle_id DESC LIMIT %s", (len(driver_ids),))
    vehicle_ids = [item[0] for item in cursor.fetchall()]
    vehicle_ids.reverse()

    for i in range(len(driver_ids)):
        driver_vehicles.append((driver_ids[i], vehicle_ids[i]))

    # Insert driver_vehicles
    query = "INSERT INTO driver_vehicles (driver_id, vehicle_id) VALUES (%s, %s)"
    cursor.executemany(query, driver_vehicles)
    db.commit()
    print(f"{cursor.rowcount} driver_vehicles inserted.")

    # Generate maintenance documents
    doc_types = ['RC (Registration Certificate)', 'Pollution Under Control (PUC) Certificate', 'Insurance Certificate', 'Fitness Certificate', 'Permit for Commercial Vehicle', 'Driver\'s License']
    for driver_id in driver_ids:
        for doc_type in doc_types:
            document_number = fake.bothify(text='??########')
            document_path = f"data/maintenance_documents/doc_{fake.uuid4()}.pdf"
            upload_date = fake.date_between(start_date="-3M", end_date="now")
            expiry_date = upload_date + timedelta(days=random.randint(30, 365))
            approval_status = random.choice(['approved', 'pending', 'rejected'])
            maintenance_docs.append((driver_id, doc_type, document_number, document_path, upload_date, expiry_date, expiry_date, approval_status))

    query = "INSERT INTO Driver_Maintenance (driver_id, document_type, document_number, document_path, upload_date, next_due_date, expiry_date, approval_status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    cursor.executemany(query, maintenance_docs)
    db.commit()
    print(f"{cursor.rowcount} maintenance documents inserted.")


def generate_admins():
    admin_ids = get_user_ids('admin')
    admins = []
    for admin_id in admin_ids:
        admins.append((admin_id,))
    
    query = "INSERT INTO Admins (admin_id) VALUES (%s)"
    cursor.executemany(query, admins)
    db.commit()
    print(f"{cursor.rowcount} admins inserted.")

def generate_passengers():
    passenger_ids = get_user_ids('passenger')
    passengers = []
    for passenger_id in passenger_ids:
        passengers.append((passenger_id,))

    query = "INSERT INTO Passengers (passenger_id) VALUES (%s)"
    cursor.executemany(query, passengers)
    db.commit()
    print(f"{cursor.rowcount} passengers inserted.")

def generate_subscription_plans():
    plans = [
        ('Basic', 1000, None, 10, 15, 10, 25, 'Monthly plan with 10 rides'),
        ('Premium', 2500, 2200, 25, 20, 10, 25, 'Monthly plan with 25 rides and discount'),
        ('Gold', 4000, 3500, 50, 25, 10, 25, 'Monthly plan with 50 rides and discount'),
        ('Corporate', 6000, None, 100, 30, 10, 25, 'Monthly plan for corporate users'),
        ('Student', 800, None, 15, 15, 10, 25, 'Discounted plan for students')
    ]
    query = "INSERT INTO subscription_plans (plan_name, price, discounted_price, max_rides, max_km_per_ride, extra_km_charge_percent, extra_ride_charge_percent, description) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    cursor.executemany(query, plans)
    db.commit()
    print(f"{cursor.rowcount} subscription plans inserted.")

def generate_subscriptions():
    passenger_ids = get_user_ids('passenger')
    plan_ids = [1, 2, 3, 4, 5]
    subscriptions = []
    for _ in range(20): # 20 passengers with subscriptions
        passenger_id = random.choice(passenger_ids)
        plan_id = random.choice(plan_ids)
        start_date = fake.date_between(start_date="-2M", end_date="now")
        end_date = start_date + timedelta(days=30)
        is_active = end_date >= datetime.now().date()
        subscriptions.append((passenger_id, plan_id, start_date, end_date, is_active))

    query = "INSERT INTO Subscriptions (passenger_id, plan_id, start_date, end_date, is_active) VALUES (%s, %s, %s, %s, %s)"
    cursor.executemany(query, subscriptions)
    db.commit()
    print(f"{cursor.rowcount} subscriptions inserted.")

def generate_rides():
    passenger_ids = get_user_ids('passenger')
    driver_ids = get_user_ids('driver')
    rides = []
    for _ in range(NUM_RIDES):
        passenger_id = random.choice(passenger_ids)
        driver_id = random.choice(driver_ids)
        
        # Randomly choose between Coimbatore and Pollachi
        if random.choice([True, False]):
            pickup_lat = random.uniform(*COIMBATORE_LAT_RANGE)
            pickup_lng = random.uniform(*COIMBATORE_LNG_RANGE)
            dropoff_lat = random.uniform(*COIMBATORE_LAT_RANGE)
            dropoff_lng = random.uniform(*COIMBATORE_LNG_RANGE)
            pickup_address = f"{fake.street_address()}, Coimbatore"
            dropoff_address = f"{fake.street_address()}, Coimbatore"
        else:
            pickup_lat = random.uniform(*POLLACHI_LAT_RANGE)
            pickup_lng = random.uniform(*POLLACHI_LNG_RANGE)
            dropoff_lat = random.uniform(*POLLACHI_LAT_RANGE)
            dropoff_lng = random.uniform(*POLLACHI_LNG_RANGE)
            pickup_address = f"{fake.street_address()}, Pollachi"
            dropoff_address = f"{fake.street_address()}, Pollachi"

        distance_km = random.uniform(1, 20) # in km
        fare = 50 + (distance_km * 15)
        driver_fare = fare * 0.8
        ride_status = random.choice(['requested', 'accepted', 'in_progress', 'completed', 'cancelled_by_driver', 'cancelled_by_passenger'])
        request_time = fake.date_time_between(start_date="-3M", end_date="now")
        start_time = request_time + timedelta(minutes=random.randint(1, 10)) if ride_status != 'requested' else None
        end_time = start_time + timedelta(minutes=random.randint(5, 60)) if ride_status == 'completed' else None
        otp = str(random.randint(1000, 9999))

        rides.append((passenger_id, driver_id, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng, pickup_address, dropoff_address, distance_km, fare, driver_fare, otp, ride_status, request_time, start_time, end_time))

    query = "INSERT INTO Rides (passenger_id, driver_id, pickup_location_lat, pickup_location_lng, dropoff_location_lat, dropoff_location_lng, pickup_address, dropoff_address, distance_km, fare, driver_fare, otp, ride_status, request_time, start_time, end_time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    cursor.executemany(query, rides)
    db.commit()
    print(f"{cursor.rowcount} rides inserted.")

def generate_payments():
    cursor.execute("SELECT ride_id, passenger_id, driver_fare FROM Rides WHERE ride_status = 'completed'")
    rides = cursor.fetchall()
    payments = []
    for ride in rides:
        ride_id, passenger_id, amount = ride
        payment_method = random.choice(['card', 'cash', 'wallet'])
        payment_status = 'completed'
        transaction_id = fake.uuid4()
        payments.append((passenger_id, ride_id, amount, payment_method, payment_status, transaction_id))

    query = "INSERT INTO Payments (user_id, ride_id, amount, payment_method, payment_status, transaction_id) VALUES (%s, %s, %s, %s, %s, %s)"
    cursor.executemany(query, payments)
    db.commit()
    print(f"{cursor.rowcount} payments inserted.")

def generate_reviews():
    cursor.execute("SELECT ride_id, driver_id, passenger_id FROM Rides WHERE ride_status = 'completed'")
    rides = cursor.fetchall()
    passenger_reviews = []
    driver_reviews = []

    for ride in rides:
        ride_id, driver_id, passenger_id = ride
        # Passenger reviews (optional)
        if random.choice([True, False]):
            rating = random.randint(1, 5)
            comment = fake.sentence()
            passenger_reviews.append((ride_id, driver_id, passenger_id, rating, comment))

        # Driver reviews (compulsory)
        rating = random.randint(1, 5)
        comment = fake.sentence()
        driver_reviews.append((ride_id, passenger_id, driver_id, rating, comment))

    # Insert passenger reviews
    query = "INSERT INTO passenger_reviews (ride_id, driver_id, passenger_id, rating, comment) VALUES (%s, %s, %s, %s, %s)"
    cursor.executemany(query, passenger_reviews)
    db.commit()
    print(f"{cursor.rowcount} passenger reviews inserted.")

    # Insert driver reviews
    query = "INSERT INTO driver_reviews (ride_id, passenger_id, driver_id, rating, comment) VALUES (%s, %s, %s, %s, %s)"
    cursor.executemany(query, driver_reviews)
    db.commit()
    print(f"{cursor.rowcount} driver reviews inserted.")

def generate_suspended_users():
    user_ids = get_user_ids('driver') + get_user_ids('passenger')
    suspended_users = []
    for _ in range(5): # Suspend 5 users
        user_id = random.choice(user_ids)
        reason = fake.sentence()
        end_date = fake.date_time_between(start_date="now", end_date="+1M")
        suspended_users.append((user_id, end_date, reason))

    # This assumes a 'suspensions' table exists. 
    # If not, you'll need to create it.
    # CREATE TABLE suspensions (
    #     suspension_id INT AUTO_INCREMENT PRIMARY KEY,
    #     user_id INT NOT NULL,
    #     end_date DATETIME NOT NULL,
    #     reason TEXT,
    #     FOREIGN KEY (user_id) REFERENCES Users(user_id)
    # );
    try:
        query = "INSERT INTO suspensions (user_id, end_date, reason) VALUES (%s, %s, %s)"
        cursor.executemany(query, suspended_users)
        db.commit()
        print(f"{cursor.rowcount} suspended users inserted.")
    except mysql.connector.Error as err:
        if err.errno == 1146:
            print("Warning: `suspensions` table not found. Skipping suspended user generation.")
        else:
            raise

def truncate_tables():
    tables = ['suspensions', 'passenger_reviews', 'driver_reviews', 'Payments', 'Rides', 'Subscriptions', 'driver_vehicles', 'Driver_Maintenance', 'Admins', 'Drivers', 'Passengers', 'subscription_plans', 'Users', 'Vehicles']
    try:
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        for table in tables:
            try:
                cursor.execute(f"TRUNCATE TABLE {table}")
                db.commit()
                print(f"Table {table} truncated.")
            except mysql.connector.Error as err:
                if err.errno == 1146: # Table not found
                    pass
                else:
                    raise
    finally:
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")

if __name__ == "__main__":
    truncate_tables()
    generate_users()
    generate_drivers()
    generate_admins()
    generate_passengers()
    generate_subscription_plans()
    generate_subscriptions()
    generate_rides()
    generate_payments()
    generate_reviews()
    generate_suspended_users()

    cursor.close()
    db.close()
