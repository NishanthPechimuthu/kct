<?php


define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'etaxi.ct.ws@gmail.com');
define('SMTP_PASSWORD', 'esdbzhinuabuvfzb');
define('SMTP_PORT', 587); 
define('SMTP_SECURE', 'tls');

define('MAIL_FROM_ADDRESS', 'no-reply@etaxi.com');
define('MAIL_FROM_NAME', 'eTaxi Verification');

define('APP_URL', 'http://localhost'); 

define('PER_KM_CHARGE', 10);
