<?php
// Local database connection
$pdo = null;

try {
    $db_host = 'localhost';
    $db_name = 'taxi';
    $db_user = 'root';
    $db_pass = 'root';
    $port = 3306;
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$db_host;port=$port;dbname=$db_name;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, $db_user, $db_pass, $options);

} catch (\PDOException $e) {
    $msg = addslashes($e->getMessage());
    echo "<script>alert('Connection failed to LOCAL database: $msg');</script>";
    $pdo = null;
}
