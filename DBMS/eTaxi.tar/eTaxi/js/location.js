document.addEventListener('DOMContentLoaded', () => {
    const updateDriverLocation = (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;

        axios.post('/api/driver.php', {
            action: 'update_location',
            lat: lat,
            lng: lng
        }).catch(error => {
            console.error('Failed to update driver location:', error);
        });
    };

    const handleLocationError = (error) => {
        console.error('Error getting location:', error);
    };

    const getLocation = () => {
        axios.get('/api/driver.php?action=get_driver_status').then(response => {
            if (response.data.success && response.data.data.current_status === 'available') {
                if (navigator.geolocation) {
                    navigator.geolocation.watchPosition(updateDriverLocation, handleLocationError, { enableHighAccuracy: true });
                } else {
                    console.error('Geolocation is not supported by this browser.');
                }
            }
        }).catch(error => {
            console.error('Failed to get driver status:', error);
        });
    };

    getLocation();
});