<?php
// /api/passenger.php

session_start();
header('Content-Type: application/json');

require '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'passenger') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$passenger_id = $_SESSION['user_id'];
$action = $_REQUEST['action'] ?? 'dashboard'; // Default to dashboard action

try {
    switch ($action) {
        case 'update_phone':
            $phone_number = $_POST['phone_number'] ?? '';
            if (!empty($phone_number)) {
                $stmt = $pdo->prepare("UPDATE users SET phone_number = ? WHERE user_id = ?");
                $stmt->execute([$phone_number, $passenger_id]);
                echo json_encode(['success' => true, 'message' => 'Phone number updated successfully.']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Phone number cannot be empty.']);
                exit;
            }

        case 'submit_review':
            $ride_id = $_POST['ride_id'] ?? null;
            $driver_id = $_POST['driver_id'] ?? null;
            $rating = $_POST['rating'] ?? null;
            $comment = $_POST['comment'] ?? null;

            if (!$ride_id || !$driver_id || !$rating) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Ride ID, driver ID, and rating are required.']);
                exit;
            }

                    $stmt = $pdo->prepare("INSERT INTO driver_reviews (ride_id, passenger_id, driver_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$ride_id, $passenger_id, $driver_id, $rating, $comment]);
            
                    echo json_encode(['success' => true, 'message' => 'Review submitted successfully!']);
                    exit;
        case 'get_wallet_balance':
            $stmt = $pdo->prepare("SELECT wallet_balance FROM Passengers WHERE passenger_id = ?");
            $stmt->execute([$passenger_id]);
            $balance = $stmt->fetchColumn();
            echo json_encode(['success' => true, 'data' => ['wallet_balance' => $balance]]);
            break;

        case 'dashboard':
            $response = [
                'success' => true,
                'data' => [
                    'subscription' => null,
                    'ride_history' => []
                ]
            ];

            $stmt = $pdo->prepare("SELECT sp.plan_name, sp.price, sp.max_rides, s.rides_taken, s.end_date FROM Subscriptions s JOIN Subscription_Plans sp ON s.plan_id = sp.plan_id WHERE s.passenger_id = ? AND s.is_active = 1 ORDER BY s.end_date DESC LIMIT 1");
            $stmt->execute([$passenger_id]);
            if ($subscription = $stmt->fetch()) {
                $response['data']['subscription'] = $subscription;
            }

            $stmt = $pdo->prepare("SELECT r.ride_id, r.pickup_address, r.dropoff_address, r.fare as ride_fare, p.amount as payment_amount, r.ride_status, r.request_time, r.otp, p.payment_id, p.payment_status, CASE WHEN dr.review_id IS NOT NULL THEN 1 ELSE 0 END AS is_reviewed FROM Rides r LEFT JOIN Payments p ON r.ride_id = p.ride_id LEFT JOIN driver_reviews dr ON r.ride_id = dr.ride_id WHERE r.passenger_id = ? AND MONTH(r.request_time) = MONTH(CURRENT_DATE()) AND YEAR(r.request_time) = YEAR(CURRENT_DATE()) ORDER BY r.request_time DESC");
            $stmt->execute([$passenger_id]);
            $response['data']['ride_history'] = $stmt->fetchAll();

            echo json_encode($response);
            break;

        case 'poll_rides':
            $ride_ids_str = $_GET['ride_ids'] ?? '';
            if (empty($ride_ids_str)) {
                echo json_encode(['success' => true, 'data' => ['ride_history' => []]]);
                exit;
            }

            $ride_ids = explode(',', $ride_ids_str);
            $placeholders = implode(',', array_fill(0, count($ride_ids), '?'));

            $stmt = $pdo->prepare("SELECT r.ride_id, r.pickup_address, r.dropoff_address, r.fare as ride_fare, p.amount as payment_amount, r.ride_status, r.request_time, r.otp, p.payment_id, p.payment_status FROM Rides r LEFT JOIN Payments p ON r.ride_id = p.ride_id WHERE r.ride_id IN ($placeholders) AND r.passenger_id = ?");
            
            $params = array_merge($ride_ids, [$passenger_id]);
            $stmt->execute($params);
            
            $response['data']['ride_history'] = $stmt->fetchAll();
            echo json_encode($response);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action.']);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>