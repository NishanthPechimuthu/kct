<?php
// /api/admin.php

$log_file = '../data/execution_log.txt';
file_put_contents($log_file, "admin.php executed at " . date('[Y-m-d H:i:s]') . "\n", FILE_APPEND);

session_start();
header('Content-Type: application/json');

require '../config/db.php';
require '../vendor/autoload.php';
require_once '../config/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendBlockEmail($email, $name) {
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port = SMTP_PORT;

        //Recipients
        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Your eTaxi Account has been Blocked';
        $mail->Body    = 'Hi ' . $name . ',<br><br>Your account on eTaxi has been blocked by an administrator. Please contact support for more information.<br><br>Thanks,<br>The eTaxi Team';

        $mail->send();
    } catch (Exception $e) {
        // Log error
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}

function sendSuspensionEmail($email, $name, $end_date, $reason) {
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port = SMTP_PORT;

        //Recipients
        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Your eTaxi Account has been Suspended';
        $mail->Body    = 'Hi ' . $name . ',<br><br>Your account on eTaxi has been suspended until ' . $end_date . '.<br>Reason: ' . $reason . '<br><br>Thanks,<br>The eTaxi Team';

        $mail->send();
    } catch (Exception $e) {
        // Log error
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}

function sendDocumentVerificationEmail($email, $name, $docType, $status, $reason = null) {
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port = SMTP_PORT;

        //Recipients
        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        if ($status === 'approved') {
            $mail->Subject = 'Your Document has been Approved';
            $mail->Body    = 'Hi ' . $name . ',<br><br>Your document, ' . $docType . ', has been approved.<br><br>Thanks,<br>The eTaxi Team';
        } else {
            $mail->Subject = 'Your Document has been Rejected';
            $mail->Body    = 'Hi ' . $name . ',<br><br>Your document, ' . $docType . ', has been rejected.<br>Reason: ' . $reason . '<br><br>Please upload a valid document.<br><br>Thanks,<br>The eTaxi Team';
        }

        $mail->send();
    } catch (Exception $e) {
        // Log error
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$admin_id = $_SESSION['user_id'];

// Ensure the admin user exists in the admins table
$stmt = $pdo->prepare("SELECT admin_id FROM admins WHERE admin_id = ?");
$stmt->execute([$admin_id]);
if ($stmt->rowCount() === 0) {
    $stmt = $pdo->prepare("INSERT INTO admins (admin_id) VALUES (?)");
    $stmt->execute([$admin_id]);
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        case 'approve_document':
            $maintenance_id = $data['maintenance_id'] ?? null;
            if (!$maintenance_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Maintenance ID is required.']);
                exit;
            }

            // Send email notification first, to ensure we have the data before updating
            $stmt = $pdo->prepare("SELECT u.email, u.full_name, dm.document_type FROM Driver_Maintenance dm JOIN Users u ON dm.driver_id = u.user_id WHERE dm.maintenance_id = ?");
            $stmt->execute([$maintenance_id]);
            $info = $stmt->fetch();

            if (!$info) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Document or user not found.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Driver_Maintenance SET approval_status = 'approved', rejection_reason = NULL, admin_id = ?, review_date = CURRENT_TIMESTAMP WHERE maintenance_id = ?");
            $stmt->execute([$admin_id, $maintenance_id]);

            sendDocumentVerificationEmail($info['email'], $info['full_name'], $info['document_type'], 'approved');

            echo json_encode(['success' => true, 'message' => 'Document approved successfully.']);
            break;

        case 'reject_document':
            $maintenance_id = $data['maintenance_id'] ?? null;
            $rejection_reason = $data['rejection_reason'] ?? null;
            if (!$maintenance_id || !$rejection_reason) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Maintenance ID and reason are required.']);
                exit;
            }

            // Send email notification first, to ensure we have the data before updating
            $stmt = $pdo->prepare("SELECT u.email, u.full_name, dm.document_type FROM Driver_Maintenance dm JOIN Users u ON dm.driver_id = u.user_id WHERE dm.maintenance_id = ?");
            $stmt->execute([$maintenance_id]);
            $info = $stmt->fetch();

            if (!$info) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Document or user not found.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Driver_Maintenance SET approval_status = 'rejected', rejection_reason = ?, admin_id = ?, review_date = CURRENT_TIMESTAMP WHERE maintenance_id = ?");
            $stmt->execute([$rejection_reason, $admin_id, $maintenance_id]);

            sendDocumentVerificationEmail($info['email'], $info['full_name'], $info['document_type'], 'rejected', $rejection_reason);

            echo json_encode(['success' => true, 'message' => 'Document rejected successfully.']);
            break;

        case 'get_dashboard_stats':
            $stmt = $pdo->query("SELECT COUNT(*) FROM Rides");
            $total_rides = $stmt->fetchColumn();

            $stmt = $pdo->query("SELECT COUNT(*) FROM Subscriptions WHERE is_active = 1");
            $active_subscriptions = $stmt->fetchColumn();

            $stmt = $pdo->query("SELECT COUNT(*) FROM Users WHERE role = 'driver' AND is_active = 1");
            $active_drivers = $stmt->fetchColumn();

            $stmt = $pdo->query("SELECT COUNT(*) FROM Users WHERE role = 'passenger' AND is_active = 1");
            $active_passengers = $stmt->fetchColumn();

            $stmt = $pdo->query("SELECT SUM(fare) FROM Rides WHERE ride_status = 'completed'");
            $total_revenue = $stmt->fetchColumn();
            $platform_earnings = $total_revenue * 0.15;

            echo json_encode([
                'success' => true,
                'data' => [
                    'total_rides' => $total_rides,
                    'active_subscriptions' => $active_subscriptions,
                    'active_drivers' => $active_drivers,
                    'active_passengers' => $active_passengers,
                    'platform_earnings' => round($platform_earnings, 2)
                ]
            ]);
            break;

        case 'get_passengers':
            $stmt = $pdo->query("SELECT user_id, full_name, email, phone_number, registration_date, is_active FROM Users WHERE role = 'passenger'");
            $passengers = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $passengers]);
            break;

        case 'update_passenger_status':
            $passenger_id = $data['passenger_id'] ?? null;
            $is_active = $data['is_active'] ?? null;

            if (!$passenger_id || !is_bool($is_active)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Passenger ID and status are required.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Users SET is_active = ? WHERE user_id = ? AND role = 'passenger'");
            $stmt->execute([(int)$is_active, $passenger_id]);

            echo json_encode(['success' => true, 'message' => 'Passenger status updated successfully.']);
            break;

        case 'get_drivers':
            $stmt = $pdo->query("SELECT u.user_id, u.full_name, u.email, u.is_active, CONCAT(v.make, ' ', v.model, ' (', v.license_plate, ')') AS vehicle_details, d.current_status, dm.document_type, dm.next_due_date, dm.approval_status, dm.maintenance_id, s.end_date AS suspension_end_date FROM Users u JOIN Drivers d ON u.user_id = d.driver_id LEFT JOIN driver_vehicles dv ON d.driver_id = dv.driver_id LEFT JOIN vehicles v ON dv.vehicle_id = v.vehicle_id LEFT JOIN ( SELECT *, ROW_NUMBER() OVER (PARTITION BY driver_id ORDER BY upload_date DESC) as rn FROM Driver_Maintenance ) dm ON d.driver_id = dm.driver_id AND dm.rn = 1 LEFT JOIN ( SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY end_date DESC) as rn FROM Suspensions WHERE end_date > NOW() ) s ON u.user_id = s.user_id AND s.rn = 1 WHERE u.role = 'driver'");
            $drivers = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $drivers]);
            break;

        case 'update_driver_status':
            $driver_id = $data['driver_id'] ?? null;
            $is_active = $data['is_active'] ?? null;

            if (!$driver_id || !is_bool($is_active)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Driver ID and status are required.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Users SET is_active = ? WHERE user_id = ? AND role = 'driver'");
            $stmt->execute([(int)$is_active, $driver_id]);

            if ($is_active == 0) {
                $stmt_user = $pdo->prepare("SELECT full_name, email FROM Users WHERE user_id = ?");
                $stmt_user->execute([$driver_id]);
                $user = $stmt_user->fetch();
                sendBlockEmail($user['email'], $user['full_name']);
            }

            echo json_encode(['success' => true, 'message' => 'Driver status updated successfully.']);
            break;

        case 'suspend_driver':
            $driver_id = $data['driver_id'] ?? null;
            $duration = $data['duration'] ?? null;
            $reason = $data['reason'] ?? null;

            if (!$driver_id || !$duration) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Driver ID and duration are required.']);
                exit;
            }

            try {
                $end_date = new DateTime();
                $end_date->add(new DateInterval($duration));
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid duration format.']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO Suspensions (user_id, end_date, reason) VALUES (?, ?, ?)");
            $stmt->execute([$driver_id, $end_date->format('Y-m-d H:i:s'), $reason]);

            $stmt_user = $pdo->prepare("SELECT full_name, email FROM Users WHERE user_id = ?");
            $stmt_user->execute([$driver_id]);
            $user = $stmt_user->fetch();
            sendSuspensionEmail($user['email'], $user['full_name'], $end_date->format('Y-m-d H:i:s'), $reason);

            echo json_encode(['success' => true, 'message' => 'Driver suspended successfully.']);
            break;

        case 'get_driver_details':
            $driver_id = $_GET['driver_id'] ?? null;

            if (!$driver_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Driver ID is required.']);
                exit;
            }

            // Get driver details
            $stmt = $pdo->prepare("SELECT u.user_id, u.full_name, u.email, u.phone_number, u.registration_date, u.is_active, CONCAT(v.make, ' ', v.model, ' (', v.license_plate, ')') AS vehicle_details, d.license_number, d.rc_number, d.current_status FROM Users u JOIN Drivers d ON u.user_id = d.driver_id LEFT JOIN driver_vehicles dv ON d.driver_id = dv.driver_id LEFT JOIN vehicles v ON dv.vehicle_id = v.vehicle_id WHERE u.user_id = ?");
            $stmt->execute([$driver_id]);
            $driver = $stmt->fetch();

            if (!$driver) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Driver not found.']);
                exit;
            }

            // Get income stats
            $today_earnings = $pdo->prepare("SELECT COALESCE(SUM(driver_fare), 0) FROM Rides WHERE driver_id = ? AND ride_status = 'completed' AND DATE(end_time) = CURDATE()");
            $today_earnings->execute([$driver_id]);
            $driver['today_earnings'] = $today_earnings->fetchColumn();

            $week_earnings = $pdo->prepare("SELECT COALESCE(SUM(driver_fare), 0) FROM Rides WHERE driver_id = ? AND ride_status = 'completed' AND YEARWEEK(end_time, 1) = YEARWEEK(CURDATE(), 1)");
            $week_earnings->execute([$driver_id]);
            $driver['week_earnings'] = $week_earnings->fetchColumn();

            $month_earnings = $pdo->prepare("SELECT COALESCE(SUM(driver_fare), 0) FROM Rides WHERE driver_id = ? AND ride_status = 'completed' AND MONTH(end_time) = MONTH(CURDATE()) AND YEAR(end_time) = YEAR(CURDATE())");
            $month_earnings->execute([$driver_id]);
            $driver['month_earnings'] = $month_earnings->fetchColumn();

            $year_earnings = $pdo->prepare("SELECT COALESCE(SUM(driver_fare), 0) FROM Rides WHERE driver_id = ? AND ride_status = 'completed' AND YEAR(end_time) = YEAR(CURDATE())");
            $year_earnings->execute([$driver_id]);
            $driver['year_earnings'] = $year_earnings->fetchColumn();

            // Get maintenance history
            $maintenance_history = $pdo->prepare("SELECT document_type, document_number, upload_date, next_due_date, expiry_date, approval_status, rejection_reason, review_date, notes FROM Driver_Maintenance WHERE driver_id = ? ORDER BY upload_date DESC");
            $maintenance_history->execute([$driver_id]);
            $driver['maintenance_history'] = $maintenance_history->fetchAll();

            echo json_encode(['success' => true, 'data' => $driver]);
            break;


        case 'update_maintenance_status':
            $maintenance_id = $data['maintenance_id'] ?? null;
            $status = $data['status'] ?? null;

            if (!$maintenance_id || !$status) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Maintenance ID and status are required.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Driver_Maintenance SET approval_status = ?, admin_id = ?, review_date = CURRENT_TIMESTAMP WHERE maintenance_id = ?");
            $stmt->execute([$status, $admin_id, $maintenance_id]);

            echo json_encode(['success' => true, 'message' => 'Maintenance status updated successfully.']);
            break;

        case 'get_subscription_plans':
            $stmt = $pdo->query("SELECT * FROM Subscription_Plans");
            $plans = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $plans]);
            break;

        case 'add_subscription_plan':
            $plan_name = $data['plan_name'] ?? null;
            $price = $data['price'] ?? null;
            $discounted_price = $data['discounted_price'] ?: null;
            $max_rides = $data['max_rides'] ?? null;
            $max_km_per_ride = $data['max_km_per_ride'] ?? null;
            $extra_km_charge_percent = $data['extra_km_charge_percent'] ?? 10.00;
            $extra_ride_charge_percent = $data['extra_ride_charge_percent'] ?? 25.00;
            $description = $data['description'] ?? null;

            if (!$plan_name || !$price || !$max_rides || !$max_km_per_ride) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'All plan details are required.']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO Subscription_Plans (plan_name, price, discounted_price, max_rides, max_km_per_ride, extra_km_charge_percent, extra_ride_charge_percent, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$plan_name, $price, $discounted_price, $max_rides, $max_km_per_ride, $extra_km_charge_percent, $extra_ride_charge_percent, $description]);

            echo json_encode(['success' => true, 'message' => 'Subscription plan added successfully.']);
            break;

        case 'update_subscription_plan':
            $plan_id = $data['plan_id'] ?? null;
            $plan_name = $data['plan_name'] ?? null;
            $price = $data['price'] ?? null;
            $discounted_price = $data['discounted_price'] ?: null;
            $max_rides = $data['max_rides'] ?? null;
            $max_km_per_ride = $data['max_km_per_ride'] ?? null;
            $extra_km_charge_percent = $data['extra_km_charge_percent'] ?? 10.00;
            $extra_ride_charge_percent = $data['extra_ride_charge_percent'] ?? 25.00;
            $description = $data['description'] ?? null;

            if (!$plan_id || !$plan_name || !$price || !$max_rides || !$max_km_per_ride) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'All plan details are required.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Subscription_Plans SET plan_name = ?, price = ?, discounted_price = ?, max_rides = ?, max_km_per_ride = ?, extra_km_charge_percent = ?, extra_ride_charge_percent = ?, description = ? WHERE plan_id = ?");
            $stmt->execute([$plan_name, $price, $discounted_price, $max_rides, $max_km_per_ride, $extra_km_charge_percent, $extra_ride_charge_percent, $description, $plan_id]);

            echo json_encode(['success' => true, 'message' => 'Subscription plan updated successfully.']);
            break;

        case 'update_plan_availability':
            $plan_id = $data['plan_id'] ?? null;
            $is_available = $data['is_available'] ?? null;

            if (!$plan_id || !is_numeric($is_available)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Plan ID and availability status are required.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Subscription_Plans SET is_available = ? WHERE plan_id = ?");
            $stmt->execute([$is_available, $plan_id]);

            echo json_encode(['success' => true, 'message' => 'Plan availability updated successfully.']);
            break;

        case 'delete_subscription_plan':
            $plan_id = $data['plan_id'] ?? null;

            if (!$plan_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Plan ID is required.']);
                exit;
            }

            $stmt = $pdo->prepare("DELETE FROM Subscription_Plans WHERE plan_id = ?");
            $stmt->execute([$plan_id]);

            echo json_encode(['success' => true, 'message' => 'Subscription plan deleted successfully.']);
            break;

        case 'get_analytics_data':
            // Rides per day for the last 30 days
            $rides_per_day_stmt = $pdo->query("SELECT DATE(request_time) as date, COUNT(*) as count FROM Rides WHERE request_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(request_time)");
            $rides_per_day = $rides_per_day_stmt->fetchAll(PDO::FETCH_ASSOC);

            // Revenue per month for the last 12 months (15% platform cut)
            $revenue_per_month_stmt = $pdo->query("SELECT DATE_FORMAT(payment_date, '%Y-%m') as month, SUM(amount) * 0.15 as total FROM Payments WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) AND payment_status = 'completed' GROUP BY DATE_FORMAT(payment_date, '%Y-%m')");
            $revenue_per_month = $revenue_per_month_stmt->fetchAll(PDO::FETCH_ASSOC);

            // User registrations per month for the last 12 months
            $users_per_month_stmt = $pdo->query("SELECT DATE_FORMAT(registration_date, '%Y-%m') as month, COUNT(*) as count FROM Users WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) GROUP BY DATE_FORMAT(registration_date, '%Y-%m')");
            $users_per_month = $users_per_month_stmt->fetchAll(PDO::FETCH_ASSOC);

            // Earnings per day for the last 30 days
            $earnings_per_day_stmt = $pdo->query("SELECT DATE(payment_date) as date, SUM(amount) * 0.15 as total FROM Payments WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND payment_status = 'completed' GROUP BY DATE(payment_date)");
            $earnings_per_day = $earnings_per_day_stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'data' => [
                    'rides_per_day' => $rides_per_day,
                    'revenue_per_month' => $revenue_per_month,
                    'users_per_month' => $users_per_month,
                    'earnings_per_day' => $earnings_per_day
                ]
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action.']);
            break;
    }
} catch (PDOException $e) {
    $log_file = '../data/error_log.txt';
    $log_entry = date('[Y-m-d H:i:s]') . " PDOException in admin.php: " . $e->getMessage() . "\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>