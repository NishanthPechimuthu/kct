<?php
// /api/driver.php
session_start();
header('Content-Type: application/json');

require '../config/db.php';
require_once '../config/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'driver') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$driver_id = $_SESSION['user_id'];

// Support both JSON and form requests
$data = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $data['action'] ?? $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        case 'update_profile':
            $phone_number = $data['phone_number'] ?? $_POST['phone_number'] ?? null;
            $license_number = $data['license_number'] ?? $_POST['license_number'] ?? null;
            $rc_number = $data['rc_number'] ?? $_POST['rc_number'] ?? null;
            $make = $data['make'] ?? $_POST['make'] ?? null;
            $model = $data['model'] ?? $_POST['model'] ?? null;
            $year = $data['year'] ?? $_POST['year'] ?? null;
            $color = $data['color'] ?? $_POST['color'] ?? null;
            $license_plate = $data['license_plate'] ?? $_POST['license_plate'] ?? null;

            if (!$phone_number || !$license_number || !$rc_number || !$make || !$model || !$year || !$color || !$license_plate) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'All fields are required.']);
                exit;
            }

            $pdo->beginTransaction();

            try {
                $stmt = $pdo->prepare("UPDATE users SET phone_number = ? WHERE user_id = ?");
                $stmt->execute([$phone_number, $driver_id]);

                $stmt = $pdo->prepare("UPDATE Drivers SET license_number = ?, rc_number = ? WHERE driver_id = ?");
                $stmt->execute([$license_number, $rc_number, $driver_id]);

                $stmt = $pdo->prepare("INSERT INTO vehicles (make, model, year, color, license_plate) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$make, $model, $year, $color, $license_plate]);
                $vehicle_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO driver_vehicles (driver_id, vehicle_id) VALUES (?, ?)");
                $stmt->execute([$driver_id, $vehicle_id]);

                $pdo->commit();

                echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;

        case 'get_ride_requests':
            $stmt = $pdo->prepare("SELECT r.ride_id, r.pickup_address, r.dropoff_address, r.driver_fare as fare, u.full_name AS passenger_name 
                FROM Rides r 
                JOIN Users u ON r.passenger_id = u.user_id 
                WHERE r.ride_status = 'requested'");
            $stmt->execute();
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'accept_ride':
            // Check if driver has a vehicle
            $stmt = $pdo->prepare("SELECT * FROM driver_vehicles WHERE driver_id = ?");
            $stmt->execute([$driver_id]);
            if (!$stmt->fetch()) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Please complete your profile and add a vehicle before accepting rides.', 'action' => 'complete_profile']);
                exit;
            }

            // Check if driver has license and rc number
            $stmt = $pdo->prepare("SELECT license_number, rc_number FROM Drivers WHERE driver_id = ?");
            $stmt->execute([$driver_id]);
            $driver = $stmt->fetch();

            if (!$driver || $driver['license_number'] === NULL || $driver['rc_number'] === NULL) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Please complete your profile before accepting rides.', 'action' => 'complete_profile']);
                exit;
            }

            // Check for missing, unapproved, or expired documents
            $required_docs = [
                'RC (Registration Certificate)',
                'Pollution Under Control (PUC) Certificate',
                'Insurance Certificate',
                'Fitness Certificate',
                'Permit for Commercial Vehicle',
                'Driver\'s License'
            ];

            $stmt = $pdo->prepare("SELECT document_type, expiry_date, approval_status FROM Driver_Maintenance WHERE driver_id = ?");
            $stmt->execute([$driver_id]);
            $driver_docs_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $driver_docs = [];
            foreach ($driver_docs_raw as $doc) {
                $driver_docs[$doc['document_type']] = $doc;
            }

            $missing_docs = array_diff($required_docs, array_keys($driver_docs));
            $unapproved_docs = false;
            $expired_docs = false;

            foreach ($required_docs as $req_doc) {
                if (isset($driver_docs[$req_doc])) {
                    $doc = $driver_docs[$req_doc];
                    if ($doc['approval_status'] !== 'approved') {
                        $unapproved_docs = true;
                    }
                    if ($doc['approval_status'] === 'approved' && strtotime($doc['expiry_date']) < time()) {
                        $expired_docs = true;
                    }
                } else {
                    $missing_docs[] = $req_doc; // Re-add to missing if not found
                }
            }

            if (!empty($missing_docs) || $unapproved_docs || $expired_docs) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'You cannot accept rides until all your documents are uploaded and approved.']);
                exit;
            }

            $ride_id = $data['ride_id'] ?? null;
            if (!$ride_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Ride ID is required.']);
                exit;
            }
            $stmt = $pdo->prepare("SELECT * FROM Rides WHERE ride_id = ? AND ride_status = 'requested'");
            $stmt->execute([$ride_id]);
            if (!$stmt->fetch()) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Ride not available or already accepted.']);
                exit;
            }
            $stmt = $pdo->prepare("UPDATE Rides SET driver_id = ?, ride_status = 'accepted', start_time = CURRENT_TIMESTAMP WHERE ride_id = ?");
            $stmt->execute([$driver_id, $ride_id]);
            echo json_encode(['success' => true, 'message' => 'Ride accepted successfully.']);
            break;

        case 'get_ride_details':
            $ride_id = $_GET['ride_id'] ?? null;
            if (!$ride_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Ride ID is required.']);
                exit;
            }
            $stmt = $pdo->prepare("SELECT r.pickup_location_lat, r.pickup_location_lng, r.dropoff_location_lat, r.dropoff_location_lng, r.pickup_address, r.dropoff_address, r.driver_fare as fare, u.full_name AS passenger_name 
                FROM Rides r 
                JOIN Users u ON r.passenger_id = u.user_id 
                WHERE r.ride_id = ? AND r.driver_id = ?");
            $stmt->execute([$ride_id, $driver_id]);
            $ride = $stmt->fetch();
            if (!$ride) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Ride not found or not assigned to you.']);
                exit;
            }
            echo json_encode(['success' => true, 'data' => $ride]);
            break;

        case 'get_maintenance_history':
            $stmt = $pdo->prepare("SELECT m.* FROM Driver_Maintenance m INNER JOIN (SELECT document_type, MAX(upload_date) AS max_upload_date FROM Driver_Maintenance WHERE driver_id = ? GROUP BY document_type) AS latest_docs ON m.document_type = latest_docs.document_type AND m.upload_date = latest_docs.max_upload_date WHERE m.driver_id = ? ORDER BY m.upload_date DESC");
            $stmt->execute([$driver_id, $driver_id]);
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'upload_maintenance_document':
            $document_type = $_POST['document_type'] ?? null;
            $document_number = $_POST['document_number'] ?? null;
            $expiry_date = $_POST['expiry_date'] ?? null;
            $file = $_FILES['document_file'] ?? null;
            if (!$document_type || !$expiry_date || !$file) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'All fields are required.']);
                exit;
            }
            $upload_dir = '../data/maintenance_documents/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $file_name = uniqid('doc_', true) . '.' . $file_extension;
            $file_path = $upload_dir . $file_name;
            if (move_uploaded_file($file['tmp_name'], $file_path)) {
                $stmt = $pdo->prepare("INSERT INTO Driver_Maintenance (driver_id, document_type, document_number, document_path, upload_date, next_due_date, expiry_date) VALUES (?, ?, ?, ?, CURDATE(), ?, ?)");
                $stmt->execute([$driver_id, $document_type, $document_number, $file_path, $expiry_date, $expiry_date]);
                echo json_encode(['success' => true, 'message' => 'Document uploaded successfully.']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to upload document.']);
            }
            break;

        case 'get_dashboard_data':
            // total earnings
            $stmt = $pdo->prepare("SELECT COALESCE(SUM(driver_fare),0) FROM Rides WHERE driver_id = ? AND ride_status = 'completed'");
            $stmt->execute([$driver_id]);
            $total_earnings = $stmt->fetchColumn();

            // completed rides
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM Rides WHERE driver_id = ? AND ride_status = 'completed'");
            $stmt->execute([$driver_id]);
            $completed_rides = $stmt->fetchColumn();

            // driver rating
            $stmt = $pdo->prepare("SELECT AVG(rating) FROM driver_reviews WHERE driver_id = ?");
            $stmt->execute([$driver_id]);
            $rating = $stmt->fetchColumn() ?: 'N/A';

            // assigned ride
            $stmt = $pdo->prepare("SELECT * FROM Rides WHERE driver_id = ? AND ride_status IN ('accepted','in_progress') LIMIT 1");
            $stmt->execute([$driver_id]);
            $assigned_ride = $stmt->fetch();

            // ride history
            $stmt = $pdo->prepare("SELECT end_time, pickup_address, dropoff_address, driver_fare as fare, ride_status FROM Rides WHERE driver_id = ? AND ride_status IN ('completed','cancelled_by_driver','cancelled_by_passenger') ORDER BY end_time DESC LIMIT 10");
            $stmt->execute([$driver_id]);
            $ride_history = $stmt->fetchAll();

            // last maintenance
            $stmt = $pdo->prepare("SELECT * FROM Driver_Maintenance WHERE driver_id = ? ORDER BY upload_date DESC LIMIT 1");
            $stmt->execute([$driver_id]);
            $last_maintenance = $stmt->fetch() ?: null;

            echo json_encode([
                'success' => true,
                'data' => [
                    'total_earnings' => round($total_earnings, 2),
                    'completed_rides' => $completed_rides,
                    'rating' => $rating,
                    'assigned_ride' => $assigned_ride,
                    'ride_history' => $ride_history,
                    'last_maintenance' => $last_maintenance
                ]
            ]);
            break;

        case 'verify_otp_and_start_ride':
            $ride_id = $data['ride_id'] ?? null;
            $otp = $data['otp'] ?? null;
            if (!$ride_id || !$otp) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Ride ID and OTP are required.']);
                exit;
            }
            $stmt = $pdo->prepare("SELECT * FROM Rides WHERE ride_id = ? AND driver_id = ?");
            $stmt->execute([$ride_id, $driver_id]);
            $ride = $stmt->fetch();
            if (!$ride) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Ride not found or not assigned to you.']);
                exit;
            }
            if ($ride['otp'] !== $otp) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid OTP.']);
                exit;
            }
            $stmt = $pdo->prepare("UPDATE Rides SET ride_status = 'in_progress' WHERE ride_id = ?");
            $stmt->execute([$ride_id]);
            $transaction_id = uniqid('txn_');
            $stmt = $pdo->prepare("INSERT INTO Payments (user_id, ride_id, amount, payment_status, transaction_id) VALUES (?, ?, 0, 'pending', ?)");
            $stmt->execute([$ride['passenger_id'], $ride_id, $transaction_id]);
            echo json_encode(['success' => true, 'message' => 'Ride started successfully.']);
            break;

        case 'complete_ride':
            $ride_id = $data['ride_id'] ?? null;
            if (!$ride_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Ride ID is required.']);
                exit;
            }
            $stmt = $pdo->prepare("UPDATE Rides SET ride_status = 'completed', end_time = CURRENT_TIMESTAMP WHERE ride_id = ? AND driver_id = ?");
            $stmt->execute([$ride_id, $driver_id]);
            
            // Get passenger_id from the ride
            $stmt = $pdo->prepare("SELECT passenger_id FROM Rides WHERE ride_id = ?");
            $stmt->execute([$ride_id]);
            $passenger_id = $stmt->fetchColumn();

            if ($passenger_id) {
                // Check for an active subscription for this passenger
                $stmt = $pdo->prepare("SELECT subscription_id FROM Subscriptions WHERE passenger_id = ? AND is_active = 1 AND end_date >= CURDATE()");
                $stmt->execute([$passenger_id]);
                $subscription_id = $stmt->fetchColumn();

                if ($subscription_id) {
                    // Increment the rides_taken count
                    $stmt = $pdo->prepare("UPDATE Subscriptions SET rides_taken = rides_taken + 1 WHERE subscription_id = ?");
                    $stmt->execute([$subscription_id]);
                }
            }

            // Get the fare from the ride to update the payment
            $stmt = $pdo->prepare("SELECT driver_fare FROM Rides WHERE ride_id = ?");
            $stmt->execute([$ride_id]);
            $ride_fare = $stmt->fetchColumn();

            if ($ride_fare !== false) {
                // Update the corresponding payment record to be completed
                $stmt = $pdo->prepare("UPDATE Payments SET amount = ?, payment_status = 'completed' WHERE ride_id = ?");
                $stmt->execute([$ride_fare, $ride_id]);
            }
            echo json_encode(['success' => true, 'message' => 'Ride completed successfully.', 'redirect' => '/driver/review.php?ride_id=' . $ride_id]);
            break;

        case 'submit_review':
            $ride_id = $_POST['ride_id'] ?? null;
            $passenger_id = $_POST['passenger_id'] ?? null;
            $rating = $_POST['rating'] ?? null;
            $comment = $_POST['comment'] ?? null;

            if (!$ride_id || !$passenger_id || !$rating) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Ride ID, passenger ID, and rating are required.']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO passenger_reviews (ride_id, driver_id, passenger_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$ride_id, $driver_id, $passenger_id, $rating, $comment]);

            header('Location: /driver/dashboard.php');
            exit;



        case 'update_location':
            $lat = $data['lat'] ?? null;
            $lng = $data['lng'] ?? null;

            if (!$lat || !$lng) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Latitude and longitude are required.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Drivers SET current_lat = ?, current_lng = ? WHERE driver_id = ?");
            $stmt->execute([$lat, $lng, $driver_id]);

            echo json_encode(['success' => true, 'message' => 'Location updated successfully.']);
            break;

        case 'update_status_and_location':
            $lat = $data['lat'] ?? null;
            $lng = $data['lng'] ?? null;

            $sql = "UPDATE Drivers SET current_status = 'available'";
            $params = [];

            if ($lat && $lng) {
                $sql .= ", current_lat = ?, current_lng = ?";
                $params[] = $lat;
                $params[] = $lng;
            }

            $sql .= " WHERE driver_id = ?";
            $params[] = $driver_id;

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            echo json_encode(['success' => true, 'message' => 'Status and location updated successfully.']);
            break;

        case 'update_status':
            $status = $data['status'] ?? null;
            if (!$status || !in_array($status, ['available', 'offline'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid status.']);
                exit;
            }

            $stmt = $pdo->prepare("UPDATE Drivers SET current_status = ? WHERE driver_id = ?");
            $stmt->execute([$status, $driver_id]);

            echo json_encode(['success' => true, 'message' => 'Status updated successfully.']);
            break;

        case 'get_driver_status':
            $stmt = $pdo->prepare("SELECT current_status FROM Drivers WHERE driver_id = ?");
            $stmt->execute([$driver_id]);
            $status = $stmt->fetchColumn();
            echo json_encode(['success' => true, 'data' => ['current_status' => $status]]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action.']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred: ' . $e->getMessage()]);
}
