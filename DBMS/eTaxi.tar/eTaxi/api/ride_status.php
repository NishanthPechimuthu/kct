<?php
// /api/ride_status.php

session_start();
header('Content-Type: application/json');

require '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'driver') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$ride_id = $_GET['ride_id'] ?? null;

if (!$ride_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Ride ID is required.']);
    exit;
}

$stmt = $pdo->prepare("SELECT ride_status FROM Rides WHERE ride_id = ?");
$stmt->execute([$ride_id]);
$ride = $stmt->fetch();

if (!$ride) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Ride not found.']);
    exit;
}

echo json_encode(['success' => true, 'data' => ['status' => $ride['ride_status']]]);
?>