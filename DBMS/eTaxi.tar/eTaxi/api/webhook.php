<?php
// /api/webhook.php

// Get the raw POST data
$payload = file_get_contents('php://input');

// Decode the JSON payload
$data = json_decode($payload, true);

// Log the data to a file
$log_file = '../data/webhook_log.txt';
$log_entry = date('[Y-m-d H:i:s]') . " Webhook Received: " . print_r($data, true) . "\n";

file_put_contents($log_file, $log_entry, FILE_APPEND);

// Respond to acknowledge receipt
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'message' => 'Webhook received']);
?>
