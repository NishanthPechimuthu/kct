# Project Brief: eTaxi Application

## 1. Use Case and Problem Scope

**Problem:** Traditional taxi services lack efficiency, price transparency, and safety, causing unpredictable waits and user concern.

**Solution:** The eTaxi application is a ride-hailing platform connecting passengers, drivers, and administrators. It provides real-time tracking, fare estimates, secure digital payments, and a rating system to ensure a reliable and safe experience for all users.

## 2. ER Diagram and Schema
(This page is intentionally left blank for the ER Diagram and schema)

## 3. Sample Populated Data
(This page is intentionally left blank for sample populated data)

## 4. SQL Schema

**`users`**: Stores core profile and authentication data for all roles.
```sql
CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `role` enum('passenger','driver','admin') NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

**`drivers`**: Contains driver-specific details, including status and location.
```sql
CREATE TABLE `drivers` (
  `driver_id` int NOT NULL,
  `license_number` varchar(50) DEFAULT NULL,
  `current_status` enum('available','on_trip','offline','maintenance_due') DEFAULT 'offline',
  `current_lat` decimal(10,8) DEFAULT NULL,
  `current_lng` decimal(11,8) DEFAULT NULL
);
```

**`passengers`**: Holds passenger-specific data like wallet balance.
```sql
CREATE TABLE `passengers` (
  `passenger_id` int NOT NULL,
  `wallet_balance` decimal(10,2) DEFAULT '0.00'
);
```

**`rides`**: Tracks the entire lifecycle of a ride, including locations, fare, and status.
```sql
CREATE TABLE `rides` (
  `ride_id` int NOT NULL,
  `passenger_id` int NOT NULL,
  `driver_id` int DEFAULT NULL,
  `pickup_location_lat` decimal(10,8) NOT NULL,
  `pickup_location_lng` decimal(11,8) NOT NULL,
  `dropoff_location_lat` decimal(10,8) NOT NULL,
  `dropoff_location_lng` decimal(11,8) NOT NULL,
  `fare` decimal(10,2) NOT NULL,
  `ride_status` enum('requested','accepted','in_progress','completed','cancelled_by_passenger','cancelled_by_driver') NOT NULL,
  `request_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

## 5. Screenshots of outputs or UI
(This page is intentionally left blank for screenshots)

## 6. Member-wise contributions
(This page is intentionally left blank for member-wise contributions)

## 7. Challenges and Future Scope

### Challenges
*   **Scalability:** Handling high volumes of concurrent ride requests.
*   **Security:** Protecting sensitive user and payment data.
*   **Real-time Sync:** Ensuring low-latency location and status updates.
*   **Verification:** Implementing a robust and efficient driver vetting process.

### Future Scope
*   **Dynamic Pricing:** Implement surge pricing based on demand.
*   **In-App Chat:** Secure communication between passengers and drivers.
*   **Scheduled Rides:** Allow users to book rides in advance.
*   **SOS/Emergency Button:** Enhance user safety with an emergency feature.
