<?php
header('Content-Type: application/json');

require '../config/db.php';

$response = ['exists' => false];

if (isset($_GET['email'])) {
    $email = $_GET['email'];

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        $response['exists'] = true;
    }
}

echo json_encode($response);
?>
