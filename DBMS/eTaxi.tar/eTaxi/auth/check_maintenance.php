<?php
// auth/check_maintenance.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is a logged-in driver
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    // Not a driver or not logged in, no action needed here
    return;
}

if (basename($_SERVER['PHP_SELF']) === 'maintenance.php') {
    return;
}

require_once __DIR__ . '/../config/db.php';

$driver_id = $_SESSION['user_id'];

$required_docs = [
    'RC (Registration Certificate)',
    'Pollution Under Control (PUC) Certificate',
    'Insurance Certificate',
    'Fitness Certificate',
    'Permit for Commercial Vehicle',
    'Driver\'s License'
];

$stmt = $pdo->prepare(
    "SELECT m.document_type, m.approval_status, m.expiry_date
    FROM Driver_Maintenance m
    INNER JOIN (
        SELECT document_type, MAX(upload_date) AS max_upload_date
        FROM Driver_Maintenance
        WHERE driver_id = ?
        GROUP BY document_type
    ) AS latest_docs ON m.document_type = latest_docs.document_type AND m.upload_date = latest_docs.max_upload_date
    WHERE m.driver_id = ?"
);
$stmt->execute([$driver_id, $driver_id]);
$driver_docs_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

$driver_docs = [];
foreach ($driver_docs_raw as $doc) {
    $driver_docs[$doc['document_type']] = $doc;
}

$missing_docs = array_diff($required_docs, array_keys($driver_docs));
$rejected_docs = false;
$expired_docs = [];
$pending_docs = false;

foreach ($required_docs as $req_doc) {
    if (isset($driver_docs[$req_doc])) {
        $doc = $driver_docs[$req_doc];
        if ($doc['approval_status'] === 'pending') {
            $pending_docs = true;
        } elseif ($doc['approval_status'] === 'rejected') {
            $rejected_docs = true;
        }

        if (new DateTime($doc['expiry_date']) < new DateTime()) {
            $expired_docs[] = $req_doc;
        }
    } else {
        $missing_docs[] = $req_doc; // Re-add to missing if not found
    }
}

if (!empty($missing_docs) || $rejected_docs || !empty($expired_docs)) {
    if (!empty($expired_docs)) {
        $_SESSION['expired_document_message'] = "Your " . $expired_docs[0] . " has expired. Please fix it.";
    }
    header('Location: /driver/maintenance.php');
    exit;
}

if ($pending_docs) {
    // If any document is pending, redirect to the pending approval page
    if (basename($_SERVER['PHP_SELF']) !== 'pending_approval.php') {
        header('Location: /driver/pending_approval.php');
        exit;
    }
    return; // Allow access to the pending approval page itself
}

// If we reach here, no documents are pending, missing, rejected, or expired.
$_SESSION['all_docs_approved'] = true;


