<?php
session_start();
require_once '../config/db.php';
require '../config/config.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = '';

$authDir = __DIR__ . '/.auth';
$jsonFile = $authDir . '/.pass.json';

// Ensure the .auth directory exists
if (!is_dir($authDir)) {
    mkdir($authDir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $token = bin2hex(random_bytes(32));
        $expires = time() + (60 * 60); // 1 hour from now

        $tokens = [];
        if (file_exists($jsonFile)) {
            $tokens = json_decode(file_get_contents($jsonFile), true);
            if (!is_array($tokens)) {
                $tokens = [];
            }
        }

        // Remove any existing tokens for this user
        $tokens = array_filter($tokens, function($t) use ($user) {
            return $t['user_id'] !== $user['user_id'];
        });

        $tokens[] = [
            'user_id' => $user['user_id'],
            'email' => $email,
            'token' => $token,
            'expires_at' => $expires
        ];

        file_put_contents($jsonFile, json_encode($tokens, JSON_PRETTY_PRINT));

        $resetLink = "http://localhost/auth/reset_password.php?token=" . $token;

        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->isSMTP();
			$mail->Host = SMTP_HOST;
			$mail->SMTPAuth = true;
			$mail->Username = SMTP_USERNAME;
			$mail->Password = SMTP_PASSWORD;
			$mail->SMTPSecure = SMTP_SECURE;
			$mail->Port = SMTP_PORT;

            //Recipients
            $mail->setFrom('no-reply@etaxi.com', 'eTaxi Support');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body    = 'Click on this link to reset your password: <a href="' . $resetLink . '">Reset Password</a>';

            $mail->send();
            $message = 'A password reset link has been sent to your email address.';
        } catch (Exception $e) {
            $message = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $message = 'No user found with that email address.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-6">Forgot Password</h2>
        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-md bg-blue-100 text-blue-700 text-center">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form action="forgot_password.php" method="POST">
            <div class="mb-4">
                <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email Address</label>
                <input type="email" id="email" name="email" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
            <div class="flex items-center justify-between">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Send Reset Link
                </button>
                <a href="/login.html" class="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
                    Back to Login
                </a>
            </div>
        </form>
    </div>
</body>
</html>