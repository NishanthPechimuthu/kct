<?php
session_start();
require_once '../config/db.php';

$message = '';

$authDir = __DIR__ . '/.auth';
$jsonFile = $authDir . '/.pass.json';

$resetRequest = null;
$tokens = [];
if (file_exists($jsonFile)) {
    $tokens = json_decode(file_get_contents($jsonFile), true);
    if (!is_array($tokens)) {
        $tokens = [];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['token'])) {
    $token = $_GET['token'];

    foreach ($tokens as $t) {
        if ($t['token'] === $token && $t['expires_at'] > time()) {
            $resetRequest = $t;
            break;
        }
    }

    if (!$resetRequest) {
        $message = 'Invalid or expired password reset token.';
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['token'], $_POST['password'], $_POST['confirm_password'])) {
    $token = $_POST['token'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($password !== $confirmPassword) {
        $message = 'Passwords do not match.';
    } else {
        $foundToken = null;
        foreach ($tokens as $t) {
            if ($t['token'] === $token && $t['expires_at'] > time()) {
                $foundToken = $t;
                break;
            }
        }

        if (!$foundToken) {
            $message = 'Invalid or expired password reset token.';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $userId = $foundToken['user_id'];

            try {
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
                $stmt->execute([$hashedPassword, $userId]);

                // Remove the used token from the array
                $tokens = array_filter($tokens, function($t) use ($token) {
                    return $t['token'] !== $token;
                });
                file_put_contents($jsonFile, json_encode($tokens, JSON_PRETTY_PRINT));

                $message = 'Your password has been reset successfully. You can now log in.';
            } catch (Exception $e) {
                $message = 'An error occurred while resetting your password.';
            }
        }
    }
} else {
    $message = 'Invalid request.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-6">Reset Password</h2>
        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-md bg-blue-100 text-blue-700 text-center">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($resetRequest): ?>
            <form action="reset_password.php" method="POST">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                <div class="mb-4">
                    <label for="password" class="block text-gray-700 text-sm font-bold mb-2">New Password</label>
                    <input type="password" id="password" name="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                <div class="mb-6">
                    <label for="confirm_password" class="block text-gray-700 text-sm font-bold mb-2">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Reset Password
                    </button>
                </div>
            </form>
        <?php else: ?>
            <p class="text-center text-gray-600">Please check your email for the reset link.</p>
        <?php endif; ?>
        <div class="mt-4 text-center">
            <a href="/login.html" class="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
                Back to Login
            </a>
        </div>
    </div>
</body>
</html>