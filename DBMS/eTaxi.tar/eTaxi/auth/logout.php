<?php
// /auth/logout.php

session_start();

require_once __DIR__ . '/../config/db.php';

if (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'driver') {
    $stmt = $pdo->prepare("UPDATE Drivers SET current_status = 'offline' WHERE driver_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
}

// Unset all of the session variables
$_SESSION = array();

// Destroy the session.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

header('Location: /index.html');
exit;
?>