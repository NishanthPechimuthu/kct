<?php
// /auth/login.php

session_start();
header('Content-Type: application/json');

require '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['email']) || empty($data['password'])) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required.']);
    exit;
}

$email = $data['email'];
$password = $data['password'];

$stmt = $pdo->prepare("SELECT * FROM Users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid credentials.']);
    exit;
}

if (!password_verify($password, $user['password_hash'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid credentials.']);
    exit;
}

if (!$user['is_active']) {
    if ($user['verification_token'] !== null) {
        echo json_encode(['success' => false, 'message' => 'Account not activated. Please check your email.']);
    } else {
        $message = 'Your account has been blocked. Please contact support for further assistance: <a href="mailto:etaxi.ct.ws@gmail.com">etaxi.ct.ws@gmail.com</a>';
        echo json_encode(['success' => false, 'message' => $message]);
    }
    exit;
}

// Check for suspension
$stmt = $pdo->prepare("SELECT * FROM Suspensions WHERE user_id = ? AND end_date > NOW() ORDER BY end_date DESC LIMIT 1");
$stmt->execute([$user['user_id']]);
$suspension = $stmt->fetch();

if ($suspension) {
    $message = 'Your account is suspended until ' . $suspension['end_date'] . '.';
    if (!empty($suspension['reason'])) {
        $message .= '<br>Reason: ' . htmlspecialchars($suspension['reason']);
    }
    $message .= '<br>Please contact support for further assistance: <a href="mailto:etaxi.ct.ws@gmail.com">etaxi.ct.ws@gmail.com</a>';
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

// Login successful
$_SESSION['user_id'] = $user['user_id'];
$_SESSION['role'] = $user['role'];
$_SESSION['full_name'] = $user['full_name'];

$redirect_url = '/';
if ($user['role'] === 'passenger') {
    $redirect_url = '../passenger/dashboard.php';
} elseif ($user['role'] === 'driver') {
    // Check for missing, unapproved, or expired documents
    $required_docs = [
        'RC (Registration Certificate)',
        'Pollution Under Control (PUC) Certificate',
        'Insurance Certificate',
        'Fitness Certificate',
        'Permit for Commercial Vehicle',
        'Driver\'s License'
    ];

    $stmt = $pdo->prepare("SELECT document_type, expiry_date, approval_status FROM Driver_Maintenance WHERE driver_id = ?");
    $stmt->execute([$user['user_id']]);
    $driver_docs_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $driver_docs = [];
    foreach ($driver_docs_raw as $doc) {
        $driver_docs[$doc['document_type']] = $doc;
    }

    $missing_docs = array_diff($required_docs, array_keys($driver_docs));
    $unapproved_docs = false;
    $expired_docs = false;

    foreach ($required_docs as $req_doc) {
        if (isset($driver_docs[$req_doc])) {
            $doc = $driver_docs[$req_doc];
            if ($doc['approval_status'] !== 'approved') {
                $unapproved_docs = true;
            }
            if ($doc['approval_status'] === 'approved' && strtotime($doc['expiry_date']) < time()) {
                $expired_docs = true;
            }
        } else {
            $missing_docs[] = $req_doc; // Re-add to missing if not found
        }
    }

    if (!empty($missing_docs) || $unapproved_docs || $expired_docs) {
        $redirect_url = '../driver/maintenance.php';
    } else {
        $stmt = $pdo->prepare("SELECT license_number, rc_number FROM Drivers WHERE driver_id = ?");
        $stmt->execute([$user['user_id']]);
        $driver = $stmt->fetch();

        if (!$driver || empty($driver['license_number']) || empty($driver['rc_number'])) {
            $redirect_url = '../driver/complete_profile.php';
        } else {
            $redirect_url = '../driver/dashboard.php';
        }
    }
} elseif ($user['role'] === 'admin') {
    $redirect_url = '../admin/dashboard.php';
}

echo json_encode(['success' => true, 'message' => 'Login successful!', 'redirect' => $redirect_url]);
