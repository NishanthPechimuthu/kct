<?php
// /auth/register.php

header('Content-Type: application/json');

require '../config/db.php';
require '../config/config.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$log_file = __DIR__ . '/../data/register_log.txt';

file_put_contents($log_file, "---\n", FILE_APPEND);
file_put_contents($log_file, date('[Y-m-d H:i:s]') . " register.php executed\n", FILE_APPEND);

$data = json_decode(file_get_contents('php://input'), true);
file_put_contents($log_file, "Request data: " . print_r($data, true) . "\n", FILE_APPEND);


// Basic validation
if (empty($data['fullName']) || empty($data['email']) || empty($data['password']) || empty($data['role'])) {
    file_put_contents($log_file, "Validation failed: All fields are required.\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

$fullName = $data['fullName'];
$email = $data['email'];
$password = $data['password'];
$role = $data['role'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    file_put_contents($log_file, "Validation failed: Invalid email format.\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Invalid email format.']);
    exit;
}

// Check if user already exists
$stmt = $pdo->prepare("SELECT * FROM Users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    file_put_contents($log_file, "Validation failed: Email already registered.\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Email already registered.']);
    exit;
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);
$verification_token = bin2hex(random_bytes(32));

$pdo->beginTransaction();

try {
    // Insert into Users table
    file_put_contents($log_file, "Inserting into Users table.\n", FILE_APPEND);
    $stmt = $pdo->prepare("INSERT INTO Users (full_name, email, password_hash, role, verification_token, is_active) VALUES (?, ?, ?, ?, ?, 0)");
    $stmt->execute([$fullName, $email, $password_hash, $role, $verification_token]);
    $user_id = $pdo->lastInsertId();
    file_put_contents($log_file, "Inserted into Users table with user_id: $user_id.\n", FILE_APPEND);

    // Insert into role-specific table
    if ($role === 'passenger') {
        file_put_contents($log_file, "Inserting into Passengers table.\n", FILE_APPEND);
        $stmt = $pdo->prepare("INSERT INTO Passengers (passenger_id) VALUES (?)");
        $stmt->execute([$user_id]);
        file_put_contents($log_file, "Inserted into Passengers table.\n", FILE_APPEND);
    } elseif ($role === 'driver') {
        file_put_contents($log_file, "Inserting into Drivers table.\n", FILE_APPEND);
        $stmt = $pdo->prepare("INSERT INTO Drivers (driver_id, license_number, rc_number) VALUES (?, NULL, NULL)");
        $stmt->execute([$user_id]);
        file_put_contents($log_file, "Inserted into Drivers table.\n", FILE_APPEND);


    }

    // Send verification email
    file_put_contents($log_file, "Sending verification email.\n", FILE_APPEND);
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME;
    $mail->Password = SMTP_PASSWORD;
    $mail->SMTPSecure = SMTP_SECURE;
    $mail->Port = SMTP_PORT;

    $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
    $mail->addAddress($email, $fullName);

    $mail->isHTML(true);
    $mail->Subject = 'Activate Your eTaxi Account';
    $verification_link = APP_URL . '/auth/verify.php?email=' . urlencode($email) . '&token=' . $verification_token;

    $emailTemplate = file_get_contents(__DIR__ . '/../templates/email_activation.html');
    $emailBody = str_replace('{USER_FULL_NAME}', $fullName, $emailTemplate);
    $emailBody = str_replace('{ACTIVATION_LINK}', $verification_link, $emailBody);

    $mail->Body    = $emailBody;

    $mail->send();
    file_put_contents($log_file, "Verification email sent.\n", FILE_APPEND);

    $pdo->commit();
    file_put_contents($log_file, "Transaction committed.\n", FILE_APPEND);

    echo json_encode(['success' => true, 'message' => 'Registration successful! Please check your email to activate your account.']);

} catch (Exception $e) {
    $pdo->rollBack();
    file_put_contents($log_file, "Exception caught: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()]);
}
