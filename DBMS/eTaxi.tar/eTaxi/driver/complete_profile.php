<?php
require_once __DIR__ . '/../auth/check_maintenance.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a driver
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'driver') {
    header('Location: /login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Your Profile - eTaxi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Update Your Profile</h1>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <p class="text-gray-600 mb-4">To see ride requests, you need to have a phone number, license number and RC number associated with your account.</p>
            <form id="complete-profile-form">
                <input type="hidden" name="action" value="update_profile">
                <div class="mb-4">
                    <label for="phone_number" class="block text-sm font-medium text-gray-700">Phone Number</label>
                    <input type="text" id="phone_number" name="phone_number" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                </div>
                <div class="mb-4">
                    <label for="license_number" class="block text-sm font-medium text-gray-700">License Number</label>
                    <input type="text" id="license_number" name="license_number" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                </div>
                <div class="mb-4">
                    <label for="rc_number" class="block text-sm font-medium text-gray-700">RC Number</label>
                    <input type="text" id="rc_number" name="rc_number" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                </div>
                <div class="mb-4">
                    <label for="make" class="block text-sm font-medium text-gray-700">Vehicle Make</label>
                    <input type="text" id="make" name="make" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" placeholder="e.g., Toyota" required>
                </div>
                <div class="mb-4">
                    <label for="model" class="block text-sm font-medium text-gray-700">Vehicle Model</label>
                    <input type="text" id="model" name="model" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" placeholder="e.g., Prius" required>
                </div>
                <div class="mb-4">
                    <label for="year" class="block text-sm font-medium text-gray-700">Vehicle Year</label>
                    <input type="number" id="year" name="year" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" placeholder="e.g., 2022" required>
                </div>
                <div class="mb-4">
                    <label for="color" class="block text-sm font-medium text-gray-700">Vehicle Color</label>
                    <input type="text" id="color" name="color" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" placeholder="e.g., White" required>
                </div>
                <div class="mb-4">
                    <label for="license_plate" class="block text-sm font-medium text-gray-700">License Plate</label>
                    <input type="text" id="license_plate" name="license_plate" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-600">Update Profile</button>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('complete-profile-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            
            try {
                const response = await axios.post('/api/driver.php', formData);
                if (response.data.success) {
                    Swal.fire('Success', 'Profile updated successfully!', 'success').then(() => {
                        window.location.href = '/driver/dashboard.php';
                    });
                } else {
                    throw new Error(response.data.message);
                }
            } catch (error) {
                Swal.fire('Error', error.message || 'Could not update profile.', 'error');
            }
        });
    </script>
</body>
</html>