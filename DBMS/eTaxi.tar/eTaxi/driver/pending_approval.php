<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a driver
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'driver') {
    header('Location: /login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documents Pending Approval - eTaxi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="text-center">
        <i class="fas fa-hourglass-half text-6xl text-blue-500 mb-4"></i>
        <h1 class="text-4xl font-bold mb-2">Documents Pending Approval</h1>
        <p class="text-gray-600 mb-8">Your uploaded documents are currently under review by our administration team. You will be notified once they are approved.</p>
        <a href="/auth/logout.php" class="bg-blue-500 text-white font-bold py-3 px-6 rounded-full hover:bg-blue-600">Logout</a>
    </div>
</body>
</html>
