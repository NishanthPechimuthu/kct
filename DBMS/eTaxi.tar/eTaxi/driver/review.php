<?php
require_once __DIR__ . '/../auth/check_maintenance.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'driver') {
    header('Location: /login.html');
    exit;
}

require '../config/db.php';

$ride_id = $_GET['ride_id'] ?? null;

if (!$ride_id) {
    header('Location: /driver/dashboard.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM rides WHERE ride_id = ? AND driver_id = ? AND ride_status = 'completed'");
$stmt->execute([$ride_id, $_SESSION['user_id']]);
$ride = $stmt->fetch();

if (!$ride) {
    header('Location: /driver/dashboard.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Your Passenger - eTaxi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Review Your Passenger</h1>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <form action="/api/driver.php" method="POST">
                <input type="hidden" name="action" value="submit_review">
                <input type="hidden" name="ride_id" value="<?= $ride_id ?>">
                <input type="hidden" name="passenger_id" value="<?= $ride['passenger_id'] ?>">
                <div class="mb-4">
                    <label for="rating" class="block text-sm font-medium text-gray-700">Rating</label>
                    <select id="rating" name="rating" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" required>
                        <option value="5">5 - Excellent</option>
                        <option value="4">4 - Good</option>
                        <option value="3">3 - Average</option>
                        <option value="2">2 - Poor</option>
                        <option value="1">1 - Terrible</option>
                    </select>
                </div>
                <div class="mb-4">
                    <label for="comment" class="block text-sm font-medium text-gray-700">Comment (Optional)</label>
                    <textarea id="comment" name="comment" rows="4" class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm"></textarea>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-600">Submit Review</button>
            </form>
        </div>
    </div>
</body>
</html>