<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /login.html');
    exit;
}

$driver_id = $_GET['driver_id'] ?? null;
if (!$driver_id) {
    header('Location: /admin/manage_drivers.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Profile - eTaxi Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-gray-100">

    <!-- Admin Navbar -->
    <nav x-data="{ isOpen: false }" class="bg-white shadow-md fixed w-full z-50 top-0">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <a class="text-2xl font-bold text-gray-800" href="/admin/dashboard.php">
                <i class="fas fa-user-shield"></i> eTaxi Admin
            </a>
            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-6 items-center">
                <a href="/admin/dashboard.php" class="text-gray-600 hover:text-blue-500">Dashboard</a>
                <a href="/admin/manage_passengers.php" class="text-gray-600 hover:text-blue-500">Passengers</a>
                <a href="/admin/manage_drivers.php" class="text-blue-500 font-bold">Drivers</a>
                <a href="/admin/verify_documents.php" class="text-gray-600 hover:text-blue-500">Verify Documents</a>
                <a href="/admin/manage_subscriptions.php" class="text-gray-600 hover:text-blue-500">Subscriptions</a>
                <a href="/admin/analytics.php" class="text-gray-600 hover:text-blue-500">Analytics</a>
                <a href="/auth/logout.php" class="text-gray-600 hover:text-blue-500">Logout</a>
            </div>
            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button @click="isOpen = !isOpen" class="text-gray-800 focus:outline-none">
                    <i :class="isOpen ? 'fas fa-times' : 'fas fa-bars'" class="h-6 w-6"></i>
                </button>
            </div>
        </div>
        <!-- Mobile Menu -->
        <div x-show="isOpen" x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 transform -translate-y-2"
             x-transition:enter-end="opacity-100 transform translate-y-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100 transform translate-y-0"
             x-transition:leave-end="opacity-0 transform -translate-y-2"
             @click.away="isOpen = false" class="md:hidden bg-white border-t">
            <a href="/admin/dashboard.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Dashboard</a>
            <a href="/admin/manage_passengers.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Passengers</a>
            <a href="/admin/manage_drivers.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Drivers</a>
            <a href="/admin/verify_documents.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Verify Documents</a>
            <a href="/admin/manage_subscriptions.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Subscriptions</a>
            <a href="/admin/analytics.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Analytics</a>
            <a href="/auth/logout.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Logout</a>
        </div>
    </nav>

    <main class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Driver Profile</h1>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-1 bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-2xl font-bold mb-4">Driver Details</h2>
                <div id="driver-details"></div>
            </div>
            <div class="lg:col-span-2 bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-2xl font-bold mb-4">Income Statistics</h2>
                <canvas id="income-chart"></canvas>
            </div>
        </div>
        <div class="mt-8 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">Maintenance History</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-800 text-white">
                        <tr>
                            <th class="py-2 px-4">Document Type</th>
                            <th class="py-2 px-4">Document Number</th>
                            <th class="py-2 px-4">Upload Date</th>
                            <th class="py-2 px-4">Next Due Date</th>
                            <th class="py-2 px-4">Expiry Date</th>
                            <th class="py-2 px-4">Status</th>
                            <th class="py-2 px-4">Rejection Reason</th>
                            <th class="py-2 px-4">Review Date</th>
                            <th class="py-2 px-4">Notes</th>
                        </tr>
                    </thead>
                    <tbody id="maintenance-history-table-body"></tbody>
                </table>
            </div>
        </div>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', async () => {
            const driverId = <?= json_encode($driver_id) ?>;
            const driverDetails = document.getElementById('driver-details');
            const incomeChartCanvas = document.getElementById('income-chart').getContext('2d');

            try {
                const response = await axios.get(`/api/admin.php?action=get_driver_details&driver_id=${driverId}`);
                if (response.data.success) {
                    const driver = response.data.data;
                    renderDriverDetails(driver);
                    renderIncomeChart(driver);
                } else {
                    driverDetails.innerHTML = `<p class="text-red-500">${response.data.message}</p>`;
                }
            } catch (error) {
                driverDetails.innerHTML = `<p class="text-red-500">An error occurred.</p>`;
            }

            function renderDriverDetails(driver) {
                const statusClass = driver.is_active ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800';
                driverDetails.innerHTML = `
                    <p><strong>ID:</strong> ${driver.user_id}</p>
                    <p><strong>Name:</strong> ${driver.full_name}</p>
                    <p><strong>Email:</strong> ${driver.email}</p>
                    <p><strong>Phone:</strong> ${driver.phone_number || 'N/A'}</p>
                    <p><strong>Vehicle:</strong> ${driver.vehicle_details}</p>
                    <p><strong>License:</strong> ${driver.license_number}</p>
                    <p><strong>RC Number:</strong> ${driver.rc_number}</p>
                    <p><strong>Ride Status:</strong> ${driver.current_status}</p>
                    <p><strong>Account Status:</strong> <span class="${statusClass} py-1 px-3 rounded-full text-xs">${driver.is_active ? 'Active' : 'Blocked'}</span></p>
                    <p><strong>Registered:</strong> ${new Date(driver.registration_date).toLocaleDateString()}</p>
                `;
            }

            function renderIncomeChart(driver) {
                new Chart(incomeChartCanvas, {
                    type: 'bar',
                    data: {
                        labels: ['Today', 'This Week', 'This Month', 'This Year'],
                        datasets: [{
                            label: 'Income (₹)',
                            data: [
                                driver.today_earnings,
                                driver.week_earnings,
                                driver.month_earnings,
                                driver.year_earnings
                            ],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255, 99, 132, 1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
        });
    </script>

</body>
</html>