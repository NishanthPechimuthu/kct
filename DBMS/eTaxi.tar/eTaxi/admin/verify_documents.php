<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /login.html');
    exit;
}

require '../config/db.php';

$stmt = $pdo->prepare("SELECT dm.*, u.full_name AS driver_name FROM Driver_Maintenance dm JOIN users u ON dm.driver_id = u.user_id WHERE dm.approval_status = 'pending' ORDER BY u.full_name, dm.upload_date DESC");
$stmt->execute();
$pending_documents_raw = $stmt->fetchAll();

// Group documents by driver
$grouped_documents = [];
foreach ($pending_documents_raw as $doc) {
    $grouped_documents[$doc['driver_name']][] = $doc;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Documents - eTaxi Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-gray-100" x-data="{ isModalOpen: false, modalUrl: '' }">

    <!-- Admin Navbar -->
    <nav x-data="{ isOpen: false }" class="bg-white shadow-md fixed w-full z-50 top-0">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <a class="text-2xl font-bold text-gray-800" href="/admin/dashboard.php">
                <i class="fas fa-user-shield"></i> eTaxi Admin
            </a>
            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-6 items-center">
                <a href="/admin/dashboard.php" class="text-gray-600 hover:text-blue-500">Dashboard</a>
                <a href="/admin/manage_passengers.php" class="text-gray-600 hover:text-blue-500">Passengers</a>
                <a href="/admin/manage_drivers.php" class="text-gray-600 hover:text-blue-500">Drivers</a>
                <a href="/admin/verify_documents.php" class="text-blue-500 font-bold">Verify Documents</a>
                <a href="/admin/manage_subscriptions.php" class="text-gray-600 hover:text-blue-500">Subscriptions</a>
                <a href="/admin/analytics.php" class="text-gray-600 hover:text-blue-500">Analytics</a>
                <a href="/auth/logout.php" class="text-gray-600 hover:text-blue-500">Logout</a>
            </div>
            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button @click="isOpen = !isOpen" class="text-gray-800 focus:outline-none">
                    <i :class="isOpen ? 'fas fa-times' : 'fas fa-bars'" class="h-6 w-6"></i>
                </button>
            </div>
        </div>
        <!-- Mobile Menu -->
        <div x-show="isOpen" x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 transform -translate-y-2"
             x-transition:enter-end="opacity-100 transform translate-y-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100 transform translate-y-0"
             x-transition:leave-end="opacity-0 transform -translate-y-2"
             @click.away="isOpen = false" class="md:hidden bg-white border-t">
            <a href="/admin/dashboard.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Dashboard</a>
            <a href="/admin/manage_passengers.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Passengers</a>
            <a href="/admin/manage_drivers.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Drivers</a>
            <a href="/admin/verify_documents.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Verify Documents</a>
            <a href="/admin/manage_subscriptions.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Subscriptions</a>
            <a href="/admin/analytics.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Analytics</a>
            <a href="/auth/logout.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Logout</a>
        </div>
    </nav>

    <main class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Pending Document Verifications</h1>
        <div class="space-y-8">
            <?php if (empty($grouped_documents)): ?>
                <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                    <p>No pending documents to verify.</p>
                </div>
            <?php else: ?>
                <?php foreach ($grouped_documents as $driver_name => $documents): ?>
                    <div class="bg-white p-6 rounded-lg shadow-lg">
                        <h2 class="text-2xl font-bold mb-4 border-b pb-2"><?= htmlspecialchars($driver_name) ?></h2>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead>
                                    <tr class="bg-gray-100">
                                        <th class="p-3">Document Type</th>
                                        <th class="p-3">Document Number</th>
                                        <th class="p-3">Document</th>
                                        <th class="p-3">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($documents as $doc): ?>
                                        <tr>
                                            <td class="p-3"><?= htmlspecialchars($doc['document_type']) ?></td>
                                            <td class="p-3"><?= htmlspecialchars($doc['document_number']) ?></td>
                                            <td class="p-3"><button @click="isModalOpen = true; modalUrl = '/<?= htmlspecialchars($doc['document_path']) ?>'" class="text-blue-500 hover:underline">View Document</button></td>
                                            <td class="p-3">
                                                <button class="bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 approve-btn" data-id="<?= $doc['maintenance_id'] ?>">Approve</button>
                                                <button class="bg-red-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-600 reject-btn" data-id="<?= $doc['maintenance_id'] ?>">Reject</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <!-- Modal -->
    <div x-show="isModalOpen" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" @keydown.escape.window="isModalOpen = false">
        <div class="bg-white rounded-lg shadow-xl p-4 w-11/12 md:w-3/4 lg:w-1/2 h-5/6 flex flex-col">
            <div class="flex justify-between items-center border-b pb-2 mb-4">
                <h3 class="text-xl font-bold">Document Viewer</h3>
                <button @click="isModalOpen = false" class="text-gray-500 hover:text-gray-800 text-3xl">&times;</button>
            </div>
            <div class="flex-grow overflow-auto">
                <iframe :src="modalUrl" class="w-full h-full" frameborder="0"></iframe>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.querySelectorAll('.approve-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const docId = e.target.dataset.id;
                Swal.fire({
                    title: 'Approving...',
                    didOpen: () => {
                        Swal.showLoading()
                    }
                });
                try {
                    const response = await axios.post('/api/admin.php', { action: 'approve_document', maintenance_id: docId });
                    if (response.data.success) {
                        Swal.fire('Approved!', 'The document has been approved.', 'success').then(() => location.reload());
                    } else {
                        throw new Error(response.data.message);
                    }
                } catch (error) {
                    Swal.fire('Error', error.message || 'Could not approve the document.', 'error');
                }
            });
        });

        document.querySelectorAll('.reject-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const docId = e.target.dataset.id;
                const { value: reason } = await Swal.fire({
                    title: 'Enter Rejection Reason',
                    input: 'textarea',
                    inputPlaceholder: 'Type your reason here...',
                    showCancelButton: true
                });

                if (reason) {
                    Swal.fire({
                        title: 'Rejecting...',
                        didOpen: () => {
                            Swal.showLoading()
                        }
                    });
                    try {
                        const response = await axios.post('/api/admin.php', { action: 'reject_document', maintenance_id: docId, rejection_reason: reason });
                        if (response.data.success) {
                            Swal.fire('Rejected!', 'The document has been rejected.', 'success').then(() => location.reload());
                        } else {
                            throw new Error(response.data.message);
                        }
                    } catch (error) {
                        Swal.fire('Error', error.message || 'Could not reject the document.', 'error');
                    }
                }
            });
        });
    </script>
</body>
</html>
