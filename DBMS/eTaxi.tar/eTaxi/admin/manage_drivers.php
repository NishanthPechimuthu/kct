<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Drivers - eTaxi Admin</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Axios & SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <style>
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .btn-xs {
            padding: 4px 8px;
            font-size: 12px;
            border-radius: 0.375rem;
            border: none;
            cursor: pointer;
            transition: 0.2s;
            text-decoration: none;
            display: inline-block;
        }
        .control-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        .control-bar select,
        .control-bar input {
            padding: 6px 10px;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            font-size: 14px;
        }
        .info {
            font-size: 0.875rem;
            color: #6b7280;
        }
        .pagination {
            display: flex;
            gap: 4px;
        }
        .pagination button {
            padding: 6px 10px;
            font-size: 14px;
            border: 1px solid #d1d5db;
            background: white;
            border-radius: 0.375rem;
            cursor: pointer;
        }
        .pagination button.active {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        @media (max-width: 768px) {
            th, td {
                font-size: 12px;
                padding: 6px 4px;
            }
            .btn-xs {
                font-size: 11px;
                padding: 3px 6px;
            }
        }
    </style>
</head>
<body class="bg-gray-100">

    <!-- Navbar -->
    <nav x-data="{ isOpen: false }" class="bg-white shadow-md fixed w-full z-50 top-0">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <a class="text-2xl font-bold text-gray-800" href="/admin/dashboard.php">
                eTaxi Admin
            </a>
            <div class="hidden md:flex space-x-6 items-center">
                <a href="/admin/dashboard.php" class="text-gray-600 hover:text-blue-500">Dashboard</a>
                <a href="/admin/manage_passengers.php" class="text-gray-600 hover:text-blue-500">Passengers</a>
                <a href="/admin/manage_drivers.php" class="text-blue-500 font-bold">Drivers</a>
                <a href="/admin/verify_documents.php" class="text-gray-600 hover:text-blue-500">Verify Documents</a>
                <a href="/admin/manage_subscriptions.php" class="text-gray-600 hover:text-blue-500">Subscriptions</a>
                <a href="/admin/analytics.php" class="text-gray-600 hover:text-blue-500">Analytics</a>
                <a href="/auth/logout.php" class="text-gray-600 hover:text-blue-500">Logout</a>
            </div>
            <div class="md:hidden">
                <button @click="isOpen = !isOpen" class="text-gray-800">
                    <i :class="isOpen ? 'fas fa-times' : 'fas fa-bars'" class="h-6 w-6"></i>
                </button>
            </div>
        </div>
        <div x-show="isOpen" @click.away="isOpen = false" class="md:hidden bg-white border-t">
            <a href="/admin/dashboard.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Dashboard</a>
            <a href="/admin/manage_passengers.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Passengers</a>
            <a href="/admin/manage_drivers.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Drivers</a>
            <a href="/admin/verify_documents.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Verify Documents</a>
            <a href="/admin/manage_subscriptions.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Subscriptions</a>
            <a href="/admin/analytics.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Analytics</a>
            <a href="/auth/logout.php" class="block py-2 px-4 text-sm hover:bg-gray-200">Logout</a>
        </div>
    </nav>

    <main class="container mx-auto px-6 py-24">
        <h1 class="text-4xl font-bold mb-8">Manage Drivers</h1>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <div class="table-container">

                <!-- Control Bar -->
                <div class="control-bar">
                    <div class="flex items-center gap-2">
                        <span class="text-sm text-gray-700">Show</span>
                        <select id="page-length">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                        <span class="text-sm text-gray-700">entries</span>
                    </div>
                    <input type="search" id="search-input" placeholder="Search drivers..." class="border rounded px-3 py-1">
                </div>

                <!-- Table -->
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Vehicle</th>
                            <th>Ride Status</th>
                            <th>Account Status</th>
                            <th>Maintenance Doc</th>
                            <th>Next Due Date</th>
                            <th>Maintenance Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="drivers-table-body">
                        <!-- Data will be injected -->
                    </tbody>
                </table>

                <!-- Info + Pagination -->
                <div class="mt-4 flex justify-between items-center">
                    <div id="table-info" class="info"></div>
                    <div id="pagination" class="pagination"></div>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Global state
        let allData = [];
        let filteredData = [];
        let currentPage = 1;
        let perPage = 10;

        // DOM Elements
        const tbody = document.getElementById('drivers-table-body');
        const pageLengthSelect = document.getElementById('page-length');
        const searchInput = document.getElementById('search-input');
        const tableInfo = document.getElementById('table-info');
        const pagination = document.getElementById('pagination');

        // Fetch drivers
        const fetchDrivers = async () => {
            try {
                const response = await axios.get('/api/admin.php?action=get_drivers');
                if (response.data.success) {
                    allData = response.data.data;
                    filteredData = allData;
                    perPage = parseInt(pageLengthSelect.value);
                    renderPage(1);
                } else {
                    showError(response.data.message);
                }
            } catch (error) {
                console.error('Fetch error:', error);
                showError('Failed to load drivers. Please try again.');
            }
        };

        // Show error in table
        const showError = (msg) => {
            tbody.innerHTML = `<tr><td colspan="9" class="text-center p-4 text-red-500">${msg}</td></tr>`;
            tableInfo.textContent = '';
            pagination.innerHTML = '';
        };

        // Render current page
        const renderPage = (page = 1) => {
            currentPage = page;
            const start = (page - 1) * perPage;
            const end = start + perPage;
            const pageData = filteredData.slice(start, end);

            tbody.innerHTML = '';
            if (pageData.length === 0) {
                tbody.innerHTML = `<tr><td colspan="9" class="text-center p-4">No drivers found.</td></tr>`;
            } else {
                pageData.forEach(d => {
                    const statusText = d.is_active ? 'Active' : 'Blocked';
                    const statusClass = d.is_active ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800';
                    const actionText = d.is_active ? 'Block' : 'Unblock';
                    const btnClass = d.is_active ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600';

                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${d.user_id}</td>
                        <td>${d.full_name}</td>
                        <td>${d.vehicle_details || 'N/A'}</td>
                        <td>${d.current_status || 'N/A'}</td>
                        <td><span class="${statusClass} py-1 px-3 rounded-full text-xs">${statusText}</span></td>
                        <td>${d.document_type || 'N/A'}</td>
                        <td>${d.next_due_date || 'N/A'}</td>
                        <td>${d.approval_status || 'N/A'}</td>
                        <td class="space-x-1">
                            <button class="btn-xs text-white ${btnClass} update-status-btn" data-id="${d.user_id}" data-status="${d.is_active ? 0 : 1}">${actionText}</button>
                            <button class="btn-xs bg-yellow-500 hover:bg-yellow-600 text-white suspend-btn" data-id="${d.user_id}">Suspend</button>
                            <a href="/admin/driver_profile.php?driver_id=${d.user_id}" class="btn-xs bg-blue-500 hover:bg-blue-600 text-white">View</a>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            }

            updateInfo();
            renderPagination();
        };

        // Update info text
        const updateInfo = () => {
            const total = filteredData.length;
            const start = total > 0 ? (currentPage - 1) * perPage + 1 : 0;
            const end = Math.min(currentPage * perPage, total);
            tableInfo.textContent = total === 0 
                ? 'No entries to show' 
                : `Showing ${start} to ${end} of ${total} entries`;
        };

        // Render pagination
        const renderPagination = () => {
            pagination.innerHTML = '';
            const totalPages = Math.ceil(filteredData.length / perPage);
            if (totalPages <= 1) return;

            for (let i = 1; i <= totalPages; i++) {
                const btn = document.createElement('button');
                btn.textContent = i;
                btn.className = i === currentPage ? 'active' : '';
                btn.onclick = () => renderPage(i);
                pagination.appendChild(btn);
            }
        };

        // Search with debounce
        const debounce = (fn, delay) => {
            let timer;
            return () => {
                clearTimeout(timer);
                timer = setTimeout(fn, delay);
            };
        };

        searchInput.oninput = debounce(() => {
            const query = searchInput.value.toLowerCase();
            filteredData = allData.filter(d =>
                Object.values(d).some(val =>
                    String(val).toLowerCase().includes(query)
                )
            );
            renderPage(1);
        }, 300);

        // Page length change
        pageLengthSelect.onchange = () => {
            perPage = parseInt(pageLengthSelect.value);
            renderPage(1);
        };

        // Event delegation for actions
        document.addEventListener('click', async (e) => {
            const target = e.target;

            // Update Status
            if (target.classList.contains('update-status-btn')) {
                const id = target.dataset.id;
                const status = target.dataset.status === '1';

                try {
                    const res = await axios.post('/api/admin.php', {
                        action: 'update_driver_status',
                        driver_id: id,
                        is_active: status
                    });
                    if (res.data.success) {
                        Swal.fire('Success', 'Driver status updated.', 'success');
                        fetchDrivers();
                    } else {
                        throw new Error(res.data.message);
                    }
                } catch (err) {
                    Swal.fire('Error', err.message || 'Update failed.', 'error');
                }
            }

            // Suspend
            if (target.classList.contains('suspend-btn')) {
                const id = target.dataset.id;

                const { value } = await Swal.fire({
                    title: 'Suspend Driver',
                    html: `
                        <select id="duration" class="swal2-select w-full mt-2">
                            <option value="P2D">2 Days</option>
                            <option value="P7D">1 Week</option>
                            <option value="P1M">1 Month</option>
                            </select>
                        <textarea id="reason" class="swal2-textarea mt-3 w-full" placeholder="Reason (required)"></textarea>
                    `,
                    preConfirm: () => {
                        const reason = document.getElementById('reason').value.trim();
                        if (!reason) {
                            Swal.showValidationMessage('Reason is required');
                            return false;
                        }
                        return {
                            duration: document.getElementById('duration').value,
                            reason
                        };
                    }
                });

                if (value) {
                    try {
                        const res = await axios.post('/api/admin.php', {
                            action: 'suspend_driver',
                            driver_id: id,
                            duration: value.duration,
                            reason: value.reason
                        });
                        if (res.data.success) {
                            Swal.fire('Success', 'Driver suspended.', 'success');
                            fetchDrivers();
                        } else {
                            throw new Error(res.data.message);
                        }
                    } catch (err) {
                        Swal.fire('Error', err.message || 'Suspend failed.', 'error');
                    }
                }
            }
        });

        // Start
        fetchDrivers();
    </script>
</body>
</html>