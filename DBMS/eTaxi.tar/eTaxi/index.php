<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eTaxi - Your City, Your Ride</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gray-100 text-gray-800">

    <?php
    require_once 'config/db.php';
    $stmt = $pdo->query("SELECT * FROM subscription_plans");
    $plans = $stmt->fetchAll();
    ?>

    <!-- Navbar -->
    <nav x-data="{ isOpen: false }" class="bg-white shadow-md fixed w-full z-50 top-0">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <a class="text-2xl font-bold text-gray-800" href="#">
                <i class="fas fa-taxi"></i> eTaxi
            </a>
            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-6 items-center">
                <a href="#plans" class="text-gray-600 hover:text-blue-500 transition-colors duration-300">Plans</a>
                <a href="#about" class="text-gray-600 hover:text-blue-500 transition-colors duration-300">About</a>
                <a href="#testimonials" class="text-gray-600 hover:text-blue-500 transition-colors duration-300">Testimonials</a>
                <a href="#contact" class="text-gray-600 hover:text-blue-500 transition-colors duration-300">Contact</a>
                <a href="/login.html" class="text-gray-600 hover:text-blue-500 transition-colors duration-300">Login</a>
                <a href="/register.html" class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600 transition-transform duration-300 transform hover:scale-105">Register</a>
            </div>
            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button @click="isOpen = !isOpen" class="text-gray-800 focus:outline-none">
                    <i :class="isOpen ? 'fas fa-times' : 'fas fa-bars'" class="h-6 w-6"></i>
                </button>
            </div>
        </div>
        <!-- Mobile Menu -->
        <div x-show="isOpen" x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 transform -translate-y-2"
             x-transition:enter-end="opacity-100 transform translate-y-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100 transform translate-y-0"
             x-transition:leave-end="opacity-0 transform -translate-y-2"
             @click.away="isOpen = false" class="md:hidden bg-white border-t">
            <a href="#plans" class="block py-2 px-4 text-sm hover:bg-gray-200">Plans</a>
            <a href="#about" class="block py-2 px-4 text-sm hover:bg-gray-200">About</a>
            <a href="#testimonials" class="block py-2 px-4 text-sm hover:bg-gray-200">Testimonials</a>
            <a href="#contact" class="block py-2 px-4 text-sm hover:bg-gray-200">Contact</a>
            <a href="/login.html" class="block py-2 px-4 text-sm hover:bg-gray-200">Login</a>
            <a href="/register.html" class="block py-2 px-4 text-sm hover:bg-gray-200">Register</a>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="bg-blue-600 text-white text-center py-32 mt-16 fade-in">
        <div class="container mx-auto px-6">
            <h1 class="text-5xl font-extrabold mb-4">Reliable Rides, Just a Tap Away</h1>
            <p class="text-xl mb-8">Join eTaxi for affordable, safe, and convenient travel across the city.</p>
            <a href="/register.html" class="bg-white text-blue-600 font-bold py-3 px-8 rounded-full hover:bg-gray-200 transition-transform duration-300 transform hover:scale-105">Get Started</a>
        </div>
    </header>

    <!-- Subscription Plans Section -->
    <section id="plans" class="py-20">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-4xl font-bold mb-2">Choose Your Way to Ride</h2>
            <p class="text-gray-600 mb-12">Flexible plans that fit your lifestyle.</p>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php foreach ($plans as $index => $plan): ?>
                        <div class="swiper-slide slide-in" style="animation-delay: <?php echo $index * 100; ?>ms">
                            <div class="bg-white rounded-lg shadow-lg p-8 transform hover:scale-105 transition-transform duration-300 <?php if ($plan['plan_id'] == 3) echo 'border-4 border-blue-500'; ?> relative">
                                <?php if ($plan['plan_id'] == 3): ?>
                                    <span class="bg-blue-500 text-white text-xs font-bold uppercase px-4 py-1 rounded-full absolute -top-4 left-1/2 -translate-x-1/2">Most Popular</span>
                                <?php endif; ?>
                                <h3 class="text-2xl font-bold mb-4"><?php echo htmlspecialchars($plan['plan_name']); ?></h3>
                                <div class="text-5xl font-extrabold mb-4">
                                    <?php if ($plan['discounted_price'] !== null): ?>
                                        <span class="text-gray-500 line-through">₹<?php echo htmlspecialchars($plan['price']); ?></span>
                                        <span>₹<?php echo htmlspecialchars($plan['discounted_price']); ?></span>
                                    <?php else: ?>
                                        <span>₹<?php echo htmlspecialchars($plan['price']); ?></span>
                                    <?php endif; ?>
                                    <span class="text-lg font-normal">/month</span>
                                </div>
                                <ul class="text-gray-600 mb-6 space-y-2">
                                    <li><i class="fas fa-check-circle text-green-500"></i> <?php echo htmlspecialchars($plan['max_rides']); ?> Rides Included</li>
                                    <li><i class="fas fa-check-circle text-green-500"></i> Up to <?php echo htmlspecialchars($plan['max_km_per_ride']); ?> KM per ride</li>
                                    <li><i class="fas fa-info-circle text-blue-500"></i> <?php echo htmlspecialchars($plan['extra_km_charge_percent']); ?>% charge for extra km</li>
                                    <li><i class="fas fa-info-circle text-blue-500"></i> <?php echo htmlspecialchars($plan['extra_ride_charge_percent']); ?>% charge for extra rides</li>
                                </ul>
                                <p class="text-gray-600 mb-6"><?php echo htmlspecialchars($plan['description']); ?></p>
                                <a href="/register.html?plan=<?php echo $plan['plan_id']; ?>" class="bg-blue-500 text-white font-bold py-3 px-6 rounded-full hover:bg-blue-600 transition-transform duration-300 transform hover:scale-105">Subscribe Now</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <!-- Add Pagination -->
                <div class="swiper-pagination"></div>
                <!-- Add Navigation -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 bg-gray-200 fade-in">
        <div class="container mx-auto px-6">
            <div class="text-center">
                <h2 class="text-4xl font-bold mb-4">About eTaxi</h2>
                <p class="text-gray-700 leading-relaxed max-w-3xl mx-auto">eTaxi is revolutionizing urban transportation by providing a seamless, reliable, and affordable taxi service. Our mission is to make your daily commute and city travel stress-free. With a fleet of well-maintained vehicles and a team of professional drivers, we are committed to your safety and comfort. We believe in leveraging technology to provide a superior experience, from easy booking through our app to transparent pricing and real-time tracking. Join us on our journey to create a smarter and more connected city.</p>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimonials" class="py-20">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-4xl font-bold mb-12">What Our Riders Say</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white rounded-lg shadow-lg p-8 transform hover:scale-105 transition-transform duration-300 slide-in">
                    <p class="text-gray-600 mb-6">"eTaxi has been a game-changer for my daily commute. The drivers are always professional and the cars are clean. I love the subscription plans!"</p>
                    <p class="font-bold">- Sarah J.</p>
                </div>
                <div class="bg-white rounded-lg shadow-lg p-8 transform hover:scale-105 transition-transform duration-300 slide-in" style="animation-delay: 100ms">
                    <p class="text-gray-600 mb-6">"I rely on eTaxi for all my business trips. The priority booking feature in the standard plan is a lifesaver. Highly recommended!"</p>
                    <p class="font-bold">- Michael B.</p>
                </div>
                <div class="bg-white rounded-lg shadow-lg p-8 transform hover:scale-105 transition-transform duration-300 slide-in" style="animation-delay: 200ms">
                    <p class="text-gray-600 mb-6">"The best taxi service in the city! The app is so easy to use and the fares are very reasonable. I feel safe and comfortable on every ride."</p>
                    <p class="font-bold">- Emily R.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="py-20 bg-gray-800 text-white fade-in">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-4xl font-bold mb-12">Contact Us</h2>
            <p>Phone no: <a href="tel:+919876543210" class="hover:text-blue-400 transition-colors duration-300">+91 9876543210</a></p>
            <p>Address: 1/2, Coimbatore, Tamil Nadu, Indian -642003</p>
            <p>Email: <a href="mailto:etaxi.ct.ws@gmail.com" class="hover:text-blue-400 transition-colors duration-300">etaxi.ct.ws@gmail.com</a></p>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-6">
        <div class="container mx-auto px-6 text-center">
            <p>&copy; 2025 eTaxi. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        var swiper = new Swiper('.swiper-container', {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            breakpoints: {
                640: {
                    slidesPerView: 1,
                    spaceBetween: 20,
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 40,
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 50,
                },
            }
        });
    </script>

</body>
</html>